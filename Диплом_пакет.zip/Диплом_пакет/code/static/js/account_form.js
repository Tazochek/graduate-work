const roleField = document.querySelector("#id_role");

function updateProfileFields() {
    const role = roleField.value;
    document.querySelectorAll(".profile-fields").forEach((element) => {
        element.hidden = !["student", "teacher"].includes(role);
    });
    document.querySelectorAll(".student-fields").forEach((element) => {
        element.hidden = role !== "student";
    });
    document.querySelectorAll(".teacher-fields").forEach((element) => {
        element.hidden = role !== "teacher";
    });
}

roleField.addEventListener("change", updateProfileFields);
updateProfileFields();
