from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q


class Speciality(models.Model):
    code = models.CharField("код", max_length=20, unique=True)
    name = models.CharField("назва", max_length=255, unique=True)

    class Meta:
        db_table = "academics_speciality"
        ordering = ("code",)
        verbose_name = "спеціальність"
        verbose_name_plural = "спеціальності"

    def __str__(self):
        return f"{self.code} — {self.name}"


class StudyGroup(models.Model):
    name = models.CharField("назва", max_length=50, unique=True)
    speciality = models.ForeignKey(
        Speciality,
        on_delete=models.PROTECT,
        related_name="study_groups",
        verbose_name="спеціальність",
    )
    admission_year = models.PositiveSmallIntegerField("рік вступу")

    class Meta:
        db_table = "academics_studygroup"
        ordering = ("name",)
        verbose_name = "навчальна група"
        verbose_name_plural = "навчальні групи"
        constraints = [
            models.CheckConstraint(
                condition=Q(admission_year__gt=0),
                name="study_group_admission_year_positive",
            )
        ]

    def __str__(self):
        return self.name


class Course(models.Model):
    class Semester(models.IntegerChoices):
        FIRST = 1, "1 семестр"
        SECOND = 2, "2 семестр"

    title = models.CharField("назва", max_length=255)
    description = models.TextField("опис", blank=True)
    credits = models.PositiveSmallIntegerField("кількість кредитів")
    semester = models.PositiveSmallIntegerField(
        "семестр",
        choices=Semester.choices,
    )
    academic_year = models.CharField("навчальний рік", max_length=9)
    teacher = models.ForeignKey(
        "accounts.TeacherProfile",
        on_delete=models.PROTECT,
        related_name="courses",
        verbose_name="викладач",
        db_index=False,
    )
    groups = models.ManyToManyField(
        StudyGroup,
        related_name="courses",
        verbose_name="навчальні групи",
    )

    class Meta:
        db_table = "academics_course"
        ordering = ("-academic_year", "semester", "title")
        verbose_name = "курс"
        verbose_name_plural = "курси"
        constraints = [
            models.CheckConstraint(
                condition=Q(credits__gt=0),
                name="course_credits_positive",
            ),
            models.CheckConstraint(
                condition=Q(semester__in=(1, 2)),
                name="course_semester_valid",
            ),
        ]
        indexes = [
            models.Index(
                fields=("academic_year", "semester"),
                name="course_year_semester_idx",
            ),
            models.Index(fields=("teacher",), name="course_teacher_idx"),
        ]

    def __str__(self):
        return f"{self.title} ({self.academic_year}, {self.semester} семестр)"


class Enrollment(models.Model):
    course = models.ForeignKey(
        Course,
        on_delete=models.PROTECT,
        related_name="enrollments",
        verbose_name="курс",
        db_index=False,
    )
    student = models.ForeignKey(
        "accounts.StudentProfile",
        on_delete=models.PROTECT,
        related_name="enrollments",
        verbose_name="студент",
        db_index=False,
    )
    study_group = models.ForeignKey(
        StudyGroup,
        on_delete=models.PROTECT,
        related_name="enrollments",
        verbose_name="навчальна група",
        db_index=False,
    )
    is_active = models.BooleanField("активне зарахування", default=True)
    enrolled_at = models.DateTimeField("дата зарахування", auto_now_add=True)

    class Meta:
        db_table = "academics_enrollment"
        ordering = ("student__last_name", "student__first_name")
        verbose_name = "зарахування"
        verbose_name_plural = "зарахування"
        constraints = [
            models.UniqueConstraint(
                fields=("course", "student"),
                name="unique_course_student_enrollment",
            )
        ]
        indexes = [
            models.Index(fields=("course",), name="enrollment_course_idx"),
            models.Index(fields=("student",), name="enrollment_student_idx"),
            models.Index(
                fields=("course", "study_group"),
                name="enrollment_course_group_idx",
            ),
        ]

    def clean(self):
        errors = {}
        if (
            self.course_id
            and self.study_group_id
            and not self.course.groups.filter(pk=self.study_group_id).exists()
        ):
            errors["study_group"] = "Обрана група не входить до цього курсу."
        if (
            self.student_id
            and self.study_group_id
            and self.student.current_group_id != self.study_group_id
        ):
            errors["student"] = "Студент не належить до обраної групи."
        if errors:
            raise ValidationError(errors)

    def __str__(self):
        return f"{self.student} — {self.course}"
