import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("academics", "0001_initial"),
        ("accounts", "0002_studentprofile_current_group_alter_user_email"),
    ]

    operations = [
        migrations.CreateModel(
            name="Course",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("title", models.CharField(max_length=255, verbose_name="назва")),
                ("description", models.TextField(blank=True, verbose_name="опис")),
                (
                    "credits",
                    models.PositiveSmallIntegerField(verbose_name="кількість кредитів"),
                ),
                (
                    "semester",
                    models.PositiveSmallIntegerField(
                        choices=[(1, "1 семестр"), (2, "2 семестр")],
                        verbose_name="семестр",
                    ),
                ),
                (
                    "academic_year",
                    models.CharField(max_length=9, verbose_name="навчальний рік"),
                ),
                (
                    "groups",
                    models.ManyToManyField(
                        related_name="courses",
                        to="academics.studygroup",
                        verbose_name="навчальні групи",
                    ),
                ),
                (
                    "teacher",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="courses",
                        to="accounts.teacherprofile",
                        verbose_name="викладач",
                    ),
                ),
            ],
            options={
                "verbose_name": "курс",
                "verbose_name_plural": "курси",
                "db_table": "academics_course",
                "ordering": ("-academic_year", "semester", "title"),
            },
        ),
        migrations.CreateModel(
            name="Enrollment",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "is_active",
                    models.BooleanField(
                        default=True, verbose_name="активне зарахування"
                    ),
                ),
                (
                    "enrolled_at",
                    models.DateTimeField(
                        auto_now_add=True, verbose_name="дата зарахування"
                    ),
                ),
                (
                    "course",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="enrollments",
                        to="academics.course",
                        verbose_name="курс",
                    ),
                ),
                (
                    "student",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="enrollments",
                        to="accounts.studentprofile",
                        verbose_name="студент",
                    ),
                ),
                (
                    "study_group",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="enrollments",
                        to="academics.studygroup",
                        verbose_name="навчальна група",
                    ),
                ),
            ],
            options={
                "verbose_name": "зарахування",
                "verbose_name_plural": "зарахування",
                "db_table": "academics_enrollment",
                "ordering": ("student__last_name", "student__first_name"),
            },
        ),
        migrations.AddIndex(
            model_name="course",
            index=models.Index(
                fields=["academic_year", "semester"], name="course_year_semester_idx"
            ),
        ),
        migrations.AddIndex(
            model_name="course",
            index=models.Index(fields=["teacher"], name="course_teacher_idx"),
        ),
        migrations.AddConstraint(
            model_name="course",
            constraint=models.CheckConstraint(
                condition=models.Q(("credits__gt", 0)), name="course_credits_positive"
            ),
        ),
        migrations.AddConstraint(
            model_name="course",
            constraint=models.CheckConstraint(
                condition=models.Q(("semester__in", (1, 2))),
                name="course_semester_valid",
            ),
        ),
        migrations.AddIndex(
            model_name="enrollment",
            index=models.Index(fields=["course"], name="enrollment_course_idx"),
        ),
        migrations.AddIndex(
            model_name="enrollment",
            index=models.Index(fields=["student"], name="enrollment_student_idx"),
        ),
        migrations.AddIndex(
            model_name="enrollment",
            index=models.Index(
                fields=["course", "study_group"], name="enrollment_course_group_idx"
            ),
        ),
        migrations.AddConstraint(
            model_name="enrollment",
            constraint=models.UniqueConstraint(
                fields=("course", "student"), name="unique_course_student_enrollment"
            ),
        ),
    ]
