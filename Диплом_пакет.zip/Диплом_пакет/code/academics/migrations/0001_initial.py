import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Speciality",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "code",
                    models.CharField(max_length=20, unique=True, verbose_name="код"),
                ),
                (
                    "name",
                    models.CharField(max_length=255, unique=True, verbose_name="назва"),
                ),
            ],
            options={
                "verbose_name": "спеціальність",
                "verbose_name_plural": "спеціальності",
                "db_table": "academics_speciality",
                "ordering": ("code",),
            },
        ),
        migrations.CreateModel(
            name="StudyGroup",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "name",
                    models.CharField(max_length=50, unique=True, verbose_name="назва"),
                ),
                (
                    "admission_year",
                    models.PositiveSmallIntegerField(verbose_name="рік вступу"),
                ),
                (
                    "speciality",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="study_groups",
                        to="academics.speciality",
                        verbose_name="спеціальність",
                    ),
                ),
            ],
            options={
                "verbose_name": "навчальна група",
                "verbose_name_plural": "навчальні групи",
                "db_table": "academics_studygroup",
                "ordering": ("name",),
                "constraints": [
                    models.CheckConstraint(
                        condition=models.Q(("admission_year__gt", 0)),
                        name="study_group_admission_year_positive",
                    )
                ],
            },
        ),
    ]
