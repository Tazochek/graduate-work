from django.contrib import admin

from .forms import CourseForm
from .models import Course, Enrollment, Speciality, StudyGroup


@admin.register(Speciality)
class SpecialityAdmin(admin.ModelAdmin):
    list_display = ("code", "name")
    search_fields = ("code", "name")


@admin.register(StudyGroup)
class StudyGroupAdmin(admin.ModelAdmin):
    list_display = ("name", "speciality", "admission_year")
    list_filter = ("speciality", "admission_year")
    search_fields = ("name",)
    list_select_related = ("speciality",)


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    form = CourseForm
    list_display = ("title", "academic_year", "semester", "teacher", "credits")
    list_filter = ("academic_year", "semester")
    search_fields = ("title", "teacher__last_name", "teacher__first_name")
    list_select_related = ("teacher",)
    filter_horizontal = ("groups",)


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ("student", "course", "study_group", "is_active", "enrolled_at")
    list_filter = ("is_active", "course", "study_group")
    search_fields = (
        "student__last_name",
        "student__first_name",
        "student__student_number",
        "course__title",
    )
    list_select_related = ("student", "course", "study_group")
