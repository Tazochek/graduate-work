from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import User
from accounts.permissions import role_required

from .forms import CourseForm, EnrollmentForm, SpecialityForm, StudyGroupForm
from .models import Course, Enrollment, Speciality, StudyGroup


def courses_for_user(user):
    """Повертає тільки ті курси, до яких роль справді має доступ."""
    courses = Course.objects.select_related("teacher__user").prefetch_related("groups")
    if user.role == User.Role.ADMIN:
        return courses
    return courses.filter(teacher__user=user)


@role_required(User.Role.ADMIN)
def speciality_list(request):
    specialities = Speciality.objects.order_by("code")
    return render(
        request,
        "academics/speciality_list.html",
        {"specialities": specialities},
    )


@role_required(User.Role.ADMIN)
def speciality_create(request):
    form = SpecialityForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Спеціальність створено.")
        return redirect("academics:speciality_list")
    return render(
        request,
        "academics/form.html",
        {"form": form, "title": "Нова спеціальність"},
    )


@role_required(User.Role.ADMIN)
def speciality_update(request, pk):
    speciality = get_object_or_404(Speciality, pk=pk)
    form = SpecialityForm(request.POST or None, instance=speciality)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Спеціальність оновлено.")
        return redirect("academics:speciality_list")
    return render(
        request,
        "academics/form.html",
        {"form": form, "title": "Редагування спеціальності"},
    )


@role_required(User.Role.ADMIN)
def study_group_list(request):
    study_groups = StudyGroup.objects.select_related("speciality").order_by("name")
    return render(
        request,
        "academics/study_group_list.html",
        {"study_groups": study_groups},
    )


@role_required(User.Role.ADMIN)
def study_group_create(request):
    form = StudyGroupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Навчальну групу створено.")
        return redirect("academics:study_group_list")
    return render(
        request,
        "academics/form.html",
        {"form": form, "title": "Нова навчальна група"},
    )


@role_required(User.Role.ADMIN)
def study_group_update(request, pk):
    study_group = get_object_or_404(StudyGroup, pk=pk)
    form = StudyGroupForm(request.POST or None, instance=study_group)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Навчальну групу оновлено.")
        return redirect("academics:study_group_list")
    return render(
        request,
        "academics/form.html",
        {"form": form, "title": "Редагування навчальної групи"},
    )


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def course_list(request):
    return render(
        request,
        "academics/course_list.html",
        {"courses": courses_for_user(request.user)},
    )


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def course_detail(request, pk):
    course = get_object_or_404(courses_for_user(request.user), pk=pk)
    enrollments = course.enrollments.select_related(
        "student__user",
        "study_group",
    )
    return render(
        request,
        "academics/course_detail.html",
        {"course": course, "enrollments": enrollments},
    )


@role_required(User.Role.ADMIN)
def course_create(request):
    form = CourseForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        course = form.save()
        messages.success(request, "Курс створено.")
        return redirect("academics:course_detail", pk=course.pk)
    return render(
        request,
        "academics/course_form.html",
        {"form": form, "title": "Новий курс"},
    )


@role_required(User.Role.ADMIN)
def course_update(request, pk):
    course = get_object_or_404(Course, pk=pk)
    form = CourseForm(request.POST or None, instance=course)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Курс оновлено.")
        return redirect("academics:course_detail", pk=course.pk)
    return render(
        request,
        "academics/course_form.html",
        {"form": form, "title": "Редагування курсу", "course": course},
    )


@role_required(User.Role.ADMIN)
def enrollment_create(request, course_pk):
    course = get_object_or_404(
        Course.objects.select_related("teacher").prefetch_related("groups"),
        pk=course_pk,
    )
    form = EnrollmentForm(request.POST or None, course=course)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Студента зараховано на курс.")
        return redirect("academics:course_detail", pk=course.pk)
    return render(
        request,
        "academics/enrollment_form.html",
        {"form": form, "course": course, "title": "Нове зарахування"},
    )


@role_required(User.Role.ADMIN)
def enrollment_update(request, course_pk, pk):
    course = get_object_or_404(Course, pk=course_pk)
    enrollment = get_object_or_404(
        Enrollment.objects.select_related("student", "study_group"),
        pk=pk,
        course=course,
    )
    form = EnrollmentForm(request.POST or None, instance=enrollment, course=course)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Зарахування оновлено.")
        return redirect("academics:course_detail", pk=course.pk)
    return render(
        request,
        "academics/enrollment_form.html",
        {"form": form, "course": course, "title": "Редагування зарахування"},
    )
