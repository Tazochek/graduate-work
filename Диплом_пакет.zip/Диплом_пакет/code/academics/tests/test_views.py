from django.test import TestCase
from django.urls import reverse

from academics.models import Course, Enrollment, Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User


class AcademicViewTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_user = User.objects.create_user(
            username="admin",
            email="admin@example.com",
            password="StrongPass123!",
            role=User.Role.ADMIN,
            is_staff=True,
        )
        cls.teacher_user = User.objects.create_user(
            username="teacher",
            email="teacher@example.com",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )

    def test_anonymous_user_is_redirected_to_login(self):
        response = self.client.get(reverse("academics:speciality_list"))
        self.assertRedirects(
            response,
            f"{reverse('accounts:login')}?next={reverse('academics:speciality_list')}",
        )

    def test_teacher_cannot_open_academic_dictionary(self):
        self.client.force_login(self.teacher_user)
        response = self.client.get(reverse("academics:speciality_list"))
        self.assertEqual(response.status_code, 403)

    def test_admin_creates_and_updates_speciality(self):
        self.client.force_login(self.admin_user)
        response = self.client.post(
            reverse("academics:speciality_create"),
            {"code": "121", "name": "Інженерія програмного забезпечення"},
        )
        self.assertRedirects(response, reverse("academics:speciality_list"))

        speciality = Speciality.objects.get(code="121")
        response = self.client.post(
            reverse("academics:speciality_update", args=[speciality.pk]),
            {"code": "121", "name": "Програмна інженерія"},
        )
        self.assertRedirects(response, reverse("academics:speciality_list"))
        speciality.refresh_from_db()
        self.assertEqual(speciality.name, "Програмна інженерія")

    def test_admin_creates_and_lists_study_group(self):
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        self.client.force_login(self.admin_user)
        response = self.client.post(
            reverse("academics:study_group_create"),
            {
                "name": "ПЗПІ-25-1",
                "speciality": speciality.pk,
                "admission_year": 2025,
            },
        )
        self.assertRedirects(response, reverse("academics:study_group_list"))
        study_group = StudyGroup.objects.get(name="ПЗПІ-25-1")

        response = self.client.get(reverse("academics:study_group_list"))
        self.assertContains(response, "ПЗПІ-25-1")
        self.assertContains(response, "121")

        response = self.client.post(
            reverse("academics:study_group_update", args=[study_group.pk]),
            {
                "name": "ПЗПІ-25-2",
                "speciality": speciality.pk,
                "admission_year": 2025,
            },
        )
        self.assertRedirects(response, reverse("academics:study_group_list"))
        study_group.refresh_from_db()
        self.assertEqual(study_group.name, "ПЗПІ-25-2")


class CourseEnrollmentViewTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_user = User.objects.create_user(
            username="course-admin",
            email="course-admin@example.com",
            password="StrongPass123!",
            role=User.Role.ADMIN,
            is_staff=True,
        )
        owner_user = User.objects.create_user(
            username="course-owner",
            email="course-owner@example.com",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )
        cls.owner_teacher = TeacherProfile.objects.create(
            user=owner_user,
            first_name="Олена",
            last_name="Коваль",
        )
        other_user = User.objects.create_user(
            username="other-teacher",
            email="other-teacher@example.com",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )
        cls.other_teacher = TeacherProfile.objects.create(
            user=other_user,
            first_name="Олег",
            last_name="Шевченко",
        )
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.first_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )
        cls.second_group = StudyGroup.objects.create(
            name="ПЗПІ-25-2",
            speciality=speciality,
            admission_year=2025,
        )
        student_user = User.objects.create_user(
            username="enrolled-student",
            email="enrolled-student@example.com",
            password="StrongPass123!",
            role=User.Role.STUDENT,
        )
        cls.student = StudentProfile.objects.create(
            user=student_user,
            first_name="Ірина",
            last_name="Мельник",
            student_number="S-301",
            enrollment_year=2025,
            current_group=cls.first_group,
        )
        cls.owner_course = Course.objects.create(
            title="Бази даних",
            credits=5,
            semester=1,
            academic_year="2025-2026",
            teacher=cls.owner_teacher,
        )
        cls.owner_course.groups.add(cls.first_group)
        cls.other_course = Course.objects.create(
            title="Комп'ютерні мережі",
            credits=4,
            semester=2,
            academic_year="2025-2026",
            teacher=cls.other_teacher,
        )
        cls.other_course.groups.add(cls.second_group)

    def test_anonymous_user_is_redirected_from_course_list(self):
        response = self.client.get(reverse("academics:course_list"))
        self.assertRedirects(
            response,
            f"{reverse('accounts:login')}?next={reverse('academics:course_list')}",
        )

    def test_admin_creates_course_and_assigns_groups(self):
        self.client.force_login(self.admin_user)
        response = self.client.post(
            reverse("academics:course_create"),
            {
                "title": "Архітектура програмного забезпечення",
                "description": "Проєктування програмних систем.",
                "credits": 5,
                "semester": 1,
                "academic_year": "2026-2027",
                "teacher": self.owner_teacher.pk,
                "groups": [self.first_group.pk, self.second_group.pk],
            },
        )

        course = Course.objects.get(title="Архітектура програмного забезпечення")
        self.assertRedirects(
            response,
            reverse("academics:course_detail", args=[course.pk]),
        )
        self.assertQuerySetEqual(
            course.groups.order_by("pk"),
            [self.first_group, self.second_group],
        )

    def test_admin_enrolls_valid_student(self):
        self.client.force_login(self.admin_user)
        response = self.client.post(
            reverse("academics:enrollment_create", args=[self.owner_course.pk]),
            {
                "student": self.student.pk,
                "study_group": self.first_group.pk,
                "is_active": True,
            },
        )
        self.assertRedirects(
            response,
            reverse("academics:course_detail", args=[self.owner_course.pk]),
        )
        self.assertTrue(
            Enrollment.objects.filter(
                course=self.owner_course,
                student=self.student,
                study_group=self.first_group,
            ).exists()
        )

    def test_teacher_sees_only_own_courses(self):
        self.client.force_login(self.owner_teacher.user)
        response = self.client.get(reverse("academics:course_list"))
        self.assertContains(response, self.owner_course.title)
        self.assertNotContains(response, self.other_course.title)

    def test_teacher_cannot_open_another_teachers_course(self):
        self.client.force_login(self.owner_teacher.user)
        response = self.client.get(
            reverse("academics:course_detail", args=[self.other_course.pk])
        )
        self.assertEqual(response.status_code, 404)

    def test_teacher_cannot_create_course(self):
        self.client.force_login(self.owner_teacher.user)
        response = self.client.get(reverse("academics:course_create"))
        self.assertEqual(response.status_code, 403)

    def test_student_cannot_edit_course(self):
        self.client.force_login(self.student.user)
        response = self.client.get(
            reverse("academics:course_update", args=[self.owner_course.pk])
        )
        self.assertEqual(response.status_code, 403)
