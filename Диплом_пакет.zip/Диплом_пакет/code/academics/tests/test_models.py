from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models.deletion import ProtectedError
from django.test import TestCase

from academics.models import Course, Enrollment, Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User


class AcademicModelTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.study_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=cls.speciality,
            admission_year=2025,
        )

    def test_speciality_code_and_name_are_unique(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            Speciality.objects.create(code="121", name="Інша назва")
        with self.assertRaises(IntegrityError), transaction.atomic():
            Speciality.objects.create(code="122", name=self.speciality.name)

    def test_study_group_name_is_unique(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            StudyGroup.objects.create(
                name=self.study_group.name,
                speciality=self.speciality,
                admission_year=2026,
            )

    def test_speciality_with_group_is_protected_from_deletion(self):
        with self.assertRaises(ProtectedError):
            self.speciality.delete()

    def test_current_group_with_student_is_protected_from_deletion(self):
        user = User.objects.create_user(
            username="student",
            email="student@example.com",
            role=User.Role.STUDENT,
        )
        StudentProfile.objects.create(
            user=user,
            first_name="Ірина",
            last_name="Мельник",
            student_number="S-001",
            enrollment_year=2025,
            current_group=self.study_group,
        )
        with self.assertRaises(ProtectedError):
            self.study_group.delete()

    def test_admission_year_must_be_positive(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            StudyGroup.objects.create(
                name="ПЗПІ-00-1",
                speciality=self.speciality,
                admission_year=0,
            )


class CourseEnrollmentModelTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.first_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )
        cls.second_group = StudyGroup.objects.create(
            name="ПЗПІ-25-2",
            speciality=speciality,
            admission_year=2025,
        )
        teacher_user = User.objects.create_user(
            username="course-teacher",
            email="course-teacher@example.com",
            role=User.Role.TEACHER,
        )
        cls.teacher = TeacherProfile.objects.create(
            user=teacher_user,
            first_name="Олена",
            last_name="Коваль",
        )
        first_student_user = User.objects.create_user(
            username="first-student",
            email="first-student@example.com",
            role=User.Role.STUDENT,
        )
        cls.first_student = StudentProfile.objects.create(
            user=first_student_user,
            first_name="Ірина",
            last_name="Мельник",
            student_number="S-101",
            enrollment_year=2025,
            current_group=cls.first_group,
        )
        second_student_user = User.objects.create_user(
            username="second-student",
            email="second-student@example.com",
            role=User.Role.STUDENT,
        )
        cls.second_student = StudentProfile.objects.create(
            user=second_student_user,
            first_name="Марія",
            last_name="Бондар",
            student_number="S-102",
            enrollment_year=2025,
            current_group=cls.second_group,
        )
        cls.course = Course.objects.create(
            title="Бази даних",
            credits=5,
            semester=Course.Semester.FIRST,
            academic_year="2025-2026",
            teacher=cls.teacher,
        )
        cls.course.groups.add(cls.first_group)

    def test_valid_enrollment_passes_domain_validation(self):
        enrollment = Enrollment(
            course=self.course,
            student=self.first_student,
            study_group=self.first_group,
        )
        enrollment.full_clean()
        enrollment.save()
        self.assertTrue(enrollment.is_active)

    def test_enrollment_rejects_group_outside_course(self):
        enrollment = Enrollment(
            course=self.course,
            student=self.second_student,
            study_group=self.second_group,
        )
        with self.assertRaises(ValidationError) as error:
            enrollment.full_clean()
        self.assertIn("study_group", error.exception.message_dict)

    def test_enrollment_rejects_student_from_another_group(self):
        enrollment = Enrollment(
            course=self.course,
            student=self.second_student,
            study_group=self.first_group,
        )
        with self.assertRaises(ValidationError) as error:
            enrollment.full_clean()
        self.assertIn("student", error.exception.message_dict)

    def test_student_cannot_be_enrolled_twice_in_same_course(self):
        Enrollment.objects.create(
            course=self.course,
            student=self.first_student,
            study_group=self.first_group,
        )
        with self.assertRaises(IntegrityError), transaction.atomic():
            Enrollment.objects.create(
                course=self.course,
                student=self.first_student,
                study_group=self.first_group,
            )

    def test_course_constraints_reject_invalid_values(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            Course.objects.create(
                title="Некоректний курс",
                credits=0,
                semester=3,
                academic_year="2025-2026",
                teacher=self.teacher,
            )
