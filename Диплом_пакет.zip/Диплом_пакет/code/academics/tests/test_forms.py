from datetime import date

from django.test import TestCase

from academics.forms import CourseForm, EnrollmentForm, StudyGroupForm
from academics.models import Course, Enrollment, Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User


class StudyGroupFormTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )

    def test_rejects_year_before_supported_range(self):
        form = StudyGroupForm(
            data={
                "name": "ПЗПІ-99-1",
                "speciality": self.speciality.pk,
                "admission_year": 1999,
            }
        )
        self.assertFalse(form.is_valid())
        self.assertIn("admission_year", form.errors)

    def test_rejects_year_after_next_calendar_year(self):
        form = StudyGroupForm(
            data={
                "name": "ПЗПІ-30-1",
                "speciality": self.speciality.pk,
                "admission_year": date.today().year + 2,
            }
        )
        self.assertFalse(form.is_valid())
        self.assertIn("admission_year", form.errors)


class CourseEnrollmentFormTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.first_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )
        cls.second_group = StudyGroup.objects.create(
            name="ПЗПІ-25-2",
            speciality=speciality,
            admission_year=2025,
        )
        teacher_user = User.objects.create_user(
            username="form-teacher",
            email="form-teacher@example.com",
            role=User.Role.TEACHER,
        )
        cls.teacher = TeacherProfile.objects.create(
            user=teacher_user,
            first_name="Олег",
            last_name="Шевченко",
        )
        student_user = User.objects.create_user(
            username="form-student",
            email="form-student@example.com",
            role=User.Role.STUDENT,
        )
        cls.student = StudentProfile.objects.create(
            user=student_user,
            first_name="Ірина",
            last_name="Мельник",
            student_number="S-201",
            enrollment_year=2025,
            current_group=cls.first_group,
        )
        cls.course = Course.objects.create(
            title="Проєктування систем",
            credits=4,
            semester=1,
            academic_year="2025-2026",
            teacher=cls.teacher,
        )
        cls.course.groups.add(cls.first_group)

    def test_course_form_rejects_invalid_academic_year_format(self):
        form = CourseForm(
            data={
                "title": "Бази даних",
                "credits": 5,
                "semester": 1,
                "academic_year": "2025/2026",
                "teacher": self.teacher.pk,
                "groups": [self.first_group.pk],
            }
        )
        self.assertFalse(form.is_valid())
        self.assertIn("academic_year", form.errors)

    def test_course_form_rejects_nonconsecutive_academic_years(self):
        form = CourseForm(
            data={
                "title": "Бази даних",
                "credits": 5,
                "semester": 1,
                "academic_year": "2025-2027",
                "teacher": self.teacher.pk,
                "groups": [self.first_group.pk],
            }
        )
        self.assertFalse(form.is_valid())
        self.assertIn("academic_year", form.errors)

    def test_enrollment_form_limits_choices_to_course_groups(self):
        form = EnrollmentForm(course=self.course)
        self.assertQuerySetEqual(
            form.fields["study_group"].queryset,
            [self.first_group],
        )
        self.assertQuerySetEqual(
            form.fields["student"].queryset,
            [self.student],
        )

    def test_enrollment_form_rejects_duplicate_student(self):
        Enrollment.objects.create(
            course=self.course,
            student=self.student,
            study_group=self.first_group,
        )
        form = EnrollmentForm(
            data={
                "student": self.student.pk,
                "study_group": self.first_group.pk,
                "is_active": True,
            },
            course=self.course,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("student", form.errors)
