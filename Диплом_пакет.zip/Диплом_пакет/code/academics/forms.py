from datetime import date
import re

from django import forms

from accounts.models import StudentProfile, TeacherProfile

from .models import Course, Enrollment, Speciality, StudyGroup


class SpecialityForm(forms.ModelForm):
    class Meta:
        model = Speciality
        fields = ("code", "name")


class StudyGroupForm(forms.ModelForm):
    class Meta:
        model = StudyGroup
        fields = ("name", "speciality", "admission_year")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        max_year = date.today().year + 1
        self.fields["speciality"].queryset = Speciality.objects.order_by("code")
        self.fields["admission_year"].widget.attrs.update(
            {"min": 2000, "max": max_year}
        )

    def clean_admission_year(self):
        year = self.cleaned_data["admission_year"]
        if not 2000 <= year <= date.today().year + 1:
            raise forms.ValidationError(
                "Рік вступу має бути від 2000 до наступного календарного року."
            )
        return year


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = (
            "title",
            "description",
            "credits",
            "semester",
            "academic_year",
            "teacher",
            "groups",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["teacher"].queryset = TeacherProfile.objects.select_related(
            "user"
        ).order_by("last_name", "first_name")
        self.fields["groups"].queryset = StudyGroup.objects.select_related(
            "speciality"
        ).order_by("name")

    def clean_academic_year(self):
        academic_year = self.cleaned_data["academic_year"]
        if not re.fullmatch(r"\d{4}-\d{4}", academic_year):
            raise forms.ValidationError(
                "Навчальний рік має формат 2025-2026."
            )
        first_year, second_year = map(int, academic_year.split("-"))
        if second_year != first_year + 1:
            raise forms.ValidationError(
                "Другий рік навчального періоду має йти одразу після першого."
            )
        return academic_year


class EnrollmentForm(forms.ModelForm):
    class Meta:
        model = Enrollment
        fields = ("student", "study_group", "is_active")

    def __init__(self, *args, course, **kwargs):
        super().__init__(*args, **kwargs)
        self.course = course
        self.instance.course = course
        course_groups = course.groups.order_by("name")
        self.fields["study_group"].queryset = course_groups
        self.fields["student"].queryset = StudentProfile.objects.filter(
            current_group__in=course_groups
        ).select_related("current_group", "user").order_by("last_name", "first_name")

    def clean_student(self):
        student = self.cleaned_data["student"]
        duplicate = Enrollment.objects.filter(
            course=self.course,
            student=student,
        ).exclude(pk=self.instance.pk)
        if duplicate.exists():
            raise forms.ValidationError("Студент уже зарахований на цей курс.")
        return student
