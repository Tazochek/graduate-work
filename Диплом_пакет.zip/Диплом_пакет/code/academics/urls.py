from django.urls import path

from . import views


app_name = "academics"

urlpatterns = [
    path("specialities/", views.speciality_list, name="speciality_list"),
    path("specialities/create/", views.speciality_create, name="speciality_create"),
    path(
        "specialities/<int:pk>/edit/",
        views.speciality_update,
        name="speciality_update",
    ),
    path("groups/", views.study_group_list, name="study_group_list"),
    path("groups/create/", views.study_group_create, name="study_group_create"),
    path(
        "groups/<int:pk>/edit/",
        views.study_group_update,
        name="study_group_update",
    ),
    path("courses/", views.course_list, name="course_list"),
    path("courses/create/", views.course_create, name="course_create"),
    path("courses/<int:pk>/", views.course_detail, name="course_detail"),
    path("courses/<int:pk>/edit/", views.course_update, name="course_update"),
    path(
        "courses/<int:course_pk>/enrollments/create/",
        views.enrollment_create,
        name="enrollment_create",
    ),
    path(
        "courses/<int:course_pk>/enrollments/<int:pk>/edit/",
        views.enrollment_update,
        name="enrollment_update",
    ),
]
