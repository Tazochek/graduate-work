from django.contrib.auth.models import AbstractUser, UserManager
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models import Q


class AccountUserManager(UserManager):
    """Зберігає створення користувача та його профілю в одному місці."""

    @transaction.atomic
    def create_account(
        self,
        *,
        username,
        email,
        password,
        role,
        profile_data=None,
    ):
        """Створює завершений акаунт або відкочує всю операцію при помилці."""
        if role not in User.Role.values:
            raise ValueError("Невідома роль користувача.")

        user = self.create_user(
            username=username,
            email=email,
            password=password,
            role=role,
            is_staff=role == User.Role.ADMIN,
        )
        profile_data = profile_data or {}

        if role == User.Role.STUDENT:
            profile = StudentProfile(user=user, **profile_data)
            profile.full_clean()
            profile.save()
        elif role == User.Role.TEACHER:
            profile = TeacherProfile(user=user, **profile_data)
            profile.full_clean()
            profile.save()

        user.validate_role_profile()
        return user

    def create_superuser(self, username, email=None, password=None, **extra_fields):
        extra_fields.setdefault("role", "admin")
        if extra_fields.get("role") != "admin":
            raise ValueError("Суперкористувач повинен мати роль адміністратора.")
        return super().create_superuser(username, email, password, **extra_fields)


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", "Адміністратор"
        TEACHER = "teacher", "Викладач"
        STUDENT = "student", "Студент"

    # Особисті дані належать профілям. Вимкнення успадкованих полів прибирає
    # два джерела правди для імені користувача.
    first_name = None
    last_name = None

    email = models.EmailField("електронна пошта", unique=True)
    role = models.CharField(
        "роль",
        max_length=10,
        choices=Role.choices,
        default=Role.STUDENT,
    )

    objects = AccountUserManager()

    class Meta:
        db_table = "accounts_user"
        verbose_name = "користувач"
        verbose_name_plural = "користувачі"

    def validate_role_profile(self):
        """Перевіряє, що роль має рівно той профіль, який їй відповідає."""
        has_student_profile = StudentProfile.objects.filter(user=self).exists()
        has_teacher_profile = TeacherProfile.objects.filter(user=self).exists()

        is_valid = {
            self.Role.ADMIN: not has_student_profile and not has_teacher_profile,
            self.Role.STUDENT: has_student_profile and not has_teacher_profile,
            self.Role.TEACHER: has_teacher_profile and not has_student_profile,
        }.get(self.role, False)
        if not is_valid:
            raise ValidationError(
                "Роль користувача не узгоджена з його профілем."
            )


class StudentProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="student_profile",
        verbose_name="користувач",
    )
    first_name = models.CharField("ім'я", max_length=150)
    last_name = models.CharField("прізвище", max_length=150)
    patronymic = models.CharField("по батькові", max_length=150, blank=True)
    student_number = models.CharField(
        "номер студентського квитка",
        max_length=50,
        unique=True,
    )
    enrollment_year = models.PositiveSmallIntegerField("рік вступу")
    current_group = models.ForeignKey(
        "academics.StudyGroup",
        on_delete=models.PROTECT,
        related_name="students",
        verbose_name="поточна група",
    )

    class Meta:
        db_table = "accounts_studentprofile"
        verbose_name = "профіль студента"
        verbose_name_plural = "профілі студентів"
        constraints = [
            models.CheckConstraint(
                condition=Q(enrollment_year__gt=0),
                name="student_enrollment_year_positive",
            )
        ]

    def clean(self):
        if self.user_id and self.user.role != User.Role.STUDENT:
            raise ValidationError(
                {"user": "Профіль студента потребує користувача з роллю студента."}
            )

    def __str__(self):
        return f"{self.last_name} {self.first_name}"


class TeacherProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="teacher_profile",
        verbose_name="користувач",
    )
    first_name = models.CharField("ім'я", max_length=150)
    last_name = models.CharField("прізвище", max_length=150)
    patronymic = models.CharField("по батькові", max_length=150, blank=True)
    position = models.CharField("посада", max_length=150, blank=True)
    academic_degree = models.CharField(
        "науковий ступінь",
        max_length=150,
        blank=True,
    )

    class Meta:
        db_table = "accounts_teacherprofile"
        verbose_name = "профіль викладача"
        verbose_name_plural = "профілі викладачів"

    def clean(self):
        if self.user_id and self.user.role != User.Role.TEACHER:
            raise ValidationError(
                {"user": "Профіль викладача потребує користувача з роллю викладача."}
            )

    def __str__(self):
        return f"{self.last_name} {self.first_name}"
