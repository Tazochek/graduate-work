from datetime import date

from django import forms
from django.contrib.auth.forms import UserCreationForm

from academics.models import StudyGroup

from .models import StudentProfile, User


class AccountCreationForm(UserCreationForm):
    first_name = forms.CharField(label="Ім'я", max_length=150, required=False)
    last_name = forms.CharField(label="Прізвище", max_length=150, required=False)
    patronymic = forms.CharField(
        label="По батькові",
        max_length=150,
        required=False,
    )
    student_number = forms.CharField(
        label="Номер студентського квитка",
        max_length=50,
        required=False,
    )
    enrollment_year = forms.IntegerField(
        label="Рік вступу",
        min_value=2000,
        max_value=date.today().year + 1,
        required=False,
    )
    current_group = forms.ModelChoiceField(
        label="Поточна група",
        queryset=StudyGroup.objects.none(),
        required=False,
    )
    position = forms.CharField(label="Посада", max_length=150, required=False)
    academic_degree = forms.CharField(
        label="Науковий ступінь",
        max_length=150,
        required=False,
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email", "role", "password1", "password2")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        max_year = date.today().year + 1
        self.fields["enrollment_year"].widget.attrs.update(
            {"min": 2000, "max": max_year}
        )
        self.fields["current_group"].queryset = StudyGroup.objects.select_related(
            "speciality"
        ).order_by("name")

    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get("role")

        if role in {User.Role.STUDENT, User.Role.TEACHER}:
            for field_name in ("first_name", "last_name"):
                if not cleaned_data.get(field_name):
                    self.add_error(field_name, "Це поле обов'язкове для профілю.")

        if role == User.Role.STUDENT:
            if not cleaned_data.get("student_number"):
                self.add_error(
                    "student_number",
                    "Номер студентського квитка обов'язковий.",
                )
            if not cleaned_data.get("enrollment_year"):
                self.add_error("enrollment_year", "Рік вступу обов'язковий.")
            if not cleaned_data.get("current_group"):
                self.add_error("current_group", "Поточна група обов'язкова.")

            student_number = cleaned_data.get("student_number")
            if student_number and StudentProfile.objects.filter(
                student_number=student_number
            ).exists():
                self.add_error(
                    "student_number",
                    "Профіль із таким номером уже існує.",
                )

        return cleaned_data

    def save(self, commit=True):
        """Передає завершене створення акаунта єдиному менеджеру моделі."""
        if not commit:
            raise ValueError("AccountCreationForm підтримує лише атомарне збереження.")

        role = self.cleaned_data["role"]
        profile_data = {}
        if role in {User.Role.STUDENT, User.Role.TEACHER}:
            profile_data.update(
                first_name=self.cleaned_data["first_name"],
                last_name=self.cleaned_data["last_name"],
                patronymic=self.cleaned_data.get("patronymic", ""),
            )
        if role == User.Role.STUDENT:
            profile_data.update(
                student_number=self.cleaned_data["student_number"],
                enrollment_year=self.cleaned_data["enrollment_year"],
                current_group=self.cleaned_data["current_group"],
            )
        elif role == User.Role.TEACHER:
            profile_data.update(
                position=self.cleaned_data.get("position", ""),
                academic_degree=self.cleaned_data.get("academic_degree", ""),
            )

        return User.objects.create_account(
            username=self.cleaned_data["username"],
            email=self.cleaned_data["email"],
            password=self.cleaned_data["password1"],
            role=role,
            profile_data=profile_data,
        )
