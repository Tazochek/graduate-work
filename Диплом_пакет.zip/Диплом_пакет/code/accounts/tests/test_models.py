from django.core.exceptions import FieldDoesNotExist, ValidationError
from django.db import IntegrityError, transaction
from django.test import TestCase

from academics.models import Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User


class UserModelTests(TestCase):
    def test_roles_are_explicit(self):
        self.assertEqual(User.Role.ADMIN, "admin")
        self.assertEqual(User.Role.TEACHER, "teacher")
        self.assertEqual(User.Role.STUDENT, "student")

    def test_user_does_not_have_name_fields(self):
        for field_name in ("first_name", "last_name"):
            with self.assertRaises(FieldDoesNotExist):
                User._meta.get_field(field_name)

    def test_superuser_receives_admin_role(self):
        user = User.objects.create_superuser(
            username="root",
            email="root@example.com",
            password="StrongPass123!",
        )
        self.assertEqual(user.role, User.Role.ADMIN)

    def test_email_is_unique(self):
        User.objects.create_user(username="first", email="same@example.com")
        with self.assertRaises(IntegrityError), transaction.atomic():
            User.objects.create_user(username="second", email="same@example.com")

    def test_student_without_profile_fails_integrity_check(self):
        user = User.objects.create_user(
            username="student-without-profile",
            role=User.Role.STUDENT,
        )
        with self.assertRaises(ValidationError):
            user.validate_role_profile()


class ProfileModelTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.study_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )

    def test_student_profile_rejects_teacher_user(self):
        teacher_user = User.objects.create_user(
            username="teacher",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )
        profile = StudentProfile(
            user=teacher_user,
            first_name="Іван",
            last_name="Петренко",
            student_number="S-001",
            enrollment_year=2025,
            current_group=self.study_group,
        )
        with self.assertRaises(ValidationError):
            profile.full_clean()

    def test_teacher_profile_rejects_student_user(self):
        student_user = User.objects.create_user(
            username="student",
            password="StrongPass123!",
            role=User.Role.STUDENT,
        )
        profile = TeacherProfile(
            user=student_user,
            first_name="Олена",
            last_name="Коваль",
        )
        with self.assertRaises(ValidationError):
            profile.full_clean()

    def test_manager_creates_student_with_valid_profile(self):
        user = User.objects.create_account(
            username="complete-student",
            email="complete@example.com",
            password="StrongPass123!",
            role=User.Role.STUDENT,
            profile_data={
                "first_name": "Ірина",
                "last_name": "Мельник",
                "student_number": "S-002",
                "enrollment_year": 2025,
                "current_group": self.study_group,
            },
        )
        user.validate_role_profile()
        self.assertEqual(user.student_profile.current_group, self.study_group)
