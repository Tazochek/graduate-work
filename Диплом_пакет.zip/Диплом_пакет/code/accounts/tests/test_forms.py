from datetime import date
from unittest.mock import patch

from django.test import TestCase

from academics.models import Speciality, StudyGroup
from accounts.forms import AccountCreationForm
from accounts.models import StudentProfile, TeacherProfile, User


class AccountCreationFormTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.study_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )

    def student_data(self, username="student1"):
        return {
            "username": username,
            "email": f"{username}@example.com",
            "role": User.Role.STUDENT,
            "password1": "StrongPass123!",
            "password2": "StrongPass123!",
            "first_name": "Ірина",
            "last_name": "Мельник",
            "patronymic": "Олегівна",
            "student_number": f"ID-{username}",
            "enrollment_year": 2025,
            "current_group": self.study_group.pk,
        }

    def test_student_user_and_profile_are_created_together(self):
        form = AccountCreationForm(data=self.student_data())
        self.assertTrue(form.is_valid(), form.errors)

        user = form.save()

        self.assertEqual(user.role, User.Role.STUDENT)
        self.assertEqual(user.student_profile.current_group, self.study_group)

    def test_teacher_user_and_profile_are_created_together(self):
        form = AccountCreationForm(
            data={
                "username": "teacher1",
                "email": "teacher1@example.com",
                "role": User.Role.TEACHER,
                "password1": "StrongPass123!",
                "password2": "StrongPass123!",
                "first_name": "Олег",
                "last_name": "Шевченко",
                "position": "Доцент",
                "academic_degree": "Кандидат технічних наук",
            }
        )
        self.assertTrue(form.is_valid(), form.errors)

        user = form.save()

        self.assertEqual(user.role, User.Role.TEACHER)
        self.assertTrue(TeacherProfile.objects.filter(user=user).exists())

    def test_student_requires_current_group(self):
        data = self.student_data()
        data.pop("current_group")
        form = AccountCreationForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn("current_group", form.errors)

    def test_enrollment_year_has_realistic_upper_bound(self):
        data = self.student_data()
        data["enrollment_year"] = date.today().year + 2
        form = AccountCreationForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn("enrollment_year", form.errors)

    def test_user_is_rolled_back_when_profile_creation_fails(self):
        form = AccountCreationForm(data=self.student_data(username="rollback"))
        self.assertTrue(form.is_valid(), form.errors)

        with patch(
            "accounts.models.StudentProfile.save",
            side_effect=RuntimeError("profile error"),
        ):
            with self.assertRaises(RuntimeError):
                form.save()

        self.assertFalse(User.objects.filter(username="rollback").exists())
