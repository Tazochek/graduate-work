from django.test import TestCase
from django.urls import reverse

from academics.models import Speciality, StudyGroup
from accounts.models import StudentProfile, User


class AccountViewTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_user = User.objects.create_user(
            username="admin",
            email="admin@example.com",
            password="StrongPass123!",
            role=User.Role.ADMIN,
            is_staff=True,
        )
        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.study_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )

    def test_anonymous_user_cannot_open_dashboard(self):
        response = self.client.get(reverse("accounts:dashboard"))

        self.assertRedirects(
            response,
            f"{reverse('accounts:login')}?next={reverse('accounts:dashboard')}",
        )

    def test_login_and_logout(self):
        response = self.client.post(
            reverse("accounts:login"),
            {"username": "admin", "password": "StrongPass123!"},
        )
        self.assertRedirects(response, reverse("accounts:dashboard"))

        response = self.client.post(reverse("accounts:logout"))
        self.assertRedirects(response, reverse("accounts:login"))

    def test_authenticated_user_is_redirected_from_login(self):
        self.client.force_login(self.admin_user)
        response = self.client.get(reverse("accounts:login"))
        self.assertRedirects(response, reverse("accounts:dashboard"))

    def test_logout_rejects_get_request(self):
        self.client.force_login(self.admin_user)
        response = self.client.get(reverse("accounts:logout"))
        self.assertEqual(response.status_code, 405)

    def test_admin_creates_student_account_with_profile(self):
        self.client.force_login(self.admin_user)
        response = self.client.post(
            reverse("accounts:create_account"),
            {
                "username": "student2",
                "email": "student2@example.com",
                "role": User.Role.STUDENT,
                "password1": "StrongPass123!",
                "password2": "StrongPass123!",
                "first_name": "Марія",
                "last_name": "Бондар",
                "student_number": "S-002",
                "enrollment_year": 2025,
                "current_group": self.study_group.pk,
            },
        )

        self.assertRedirects(response, reverse("accounts:dashboard"))
        created_user = User.objects.get(username="student2")
        self.assertTrue(StudentProfile.objects.filter(user=created_user).exists())

    def test_teacher_cannot_open_account_creation(self):
        teacher = User.objects.create_user(
            username="teacher2",
            email="teacher2@example.com",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )
        self.client.force_login(teacher)

        response = self.client.get(reverse("accounts:create_account"))

        self.assertEqual(response.status_code, 403)
