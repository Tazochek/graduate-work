from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from .forms import AccountCreationForm
from .models import User
from .permissions import role_required


@login_required
def dashboard(request):
    return render(request, "accounts/dashboard.html")


@role_required(User.Role.ADMIN)
def create_account(request):
    form = AccountCreationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        created_user = form.save()
        messages.success(
            request,
            f"Обліковий запис {created_user.username} створено.",
        )
        return redirect("accounts:dashboard")

    return render(request, "accounts/account_form.html", {"form": form})
