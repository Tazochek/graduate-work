from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import StudentProfile, TeacherProfile, User


@admin.register(User)
class AccountUserAdmin(UserAdmin):
    list_display = ("username", "email", "role", "is_active", "is_staff")
    list_filter = ("role", "is_active", "is_staff")
    search_fields = ("username", "email")
    ordering = ("username",)
    readonly_fields = ("role",)
    fieldsets = (
        (None, {"fields": ("username", "password")}),
        ("Контакти", {"fields": ("email", "role")}),
        (
            "Доступ",
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                )
            },
        ),
        ("Дати", {"fields": ("last_login", "date_joined")}),
    )

    def has_add_permission(self, request):
        # Додавання вимкнено, бо стандартна форма Django створила б User без
        # обов'язкового профілю. Для цього є атомарна прикладна форма.
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = (
        "student_number",
        "last_name",
        "first_name",
        "current_group",
        "enrollment_year",
    )
    list_select_related = ("current_group",)
    search_fields = ("student_number", "last_name", "first_name")
    readonly_fields = ("user",)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(TeacherProfile)
class TeacherProfileAdmin(admin.ModelAdmin):
    list_display = ("last_name", "first_name", "position", "academic_degree")
    search_fields = ("last_name", "first_name")
    readonly_fields = ("user",)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
