# Створено Django 5.2.15 18 червня 2026 року.

import accounts.models
import django.contrib.auth.validators
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [
        migrations.CreateModel(
            name="User",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("password", models.CharField(max_length=128, verbose_name="password")),
                (
                    "last_login",
                    models.DateTimeField(
                        blank=True, null=True, verbose_name="last login"
                    ),
                ),
                (
                    "is_superuser",
                    models.BooleanField(
                        default=False,
                        help_text="Designates that this user has all permissions without explicitly assigning them.",
                        verbose_name="superuser status",
                    ),
                ),
                (
                    "username",
                    models.CharField(
                        error_messages={
                            "unique": "A user with that username already exists."
                        },
                        help_text="Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.",
                        max_length=150,
                        unique=True,
                        validators=[
                            django.contrib.auth.validators.UnicodeUsernameValidator()
                        ],
                        verbose_name="username",
                    ),
                ),
                (
                    "is_staff",
                    models.BooleanField(
                        default=False,
                        help_text="Designates whether the user can log into this admin site.",
                        verbose_name="staff status",
                    ),
                ),
                (
                    "is_active",
                    models.BooleanField(
                        default=True,
                        help_text="Designates whether this user should be treated as active. Unselect this instead of deleting accounts.",
                        verbose_name="active",
                    ),
                ),
                (
                    "date_joined",
                    models.DateTimeField(
                        default=django.utils.timezone.now, verbose_name="date joined"
                    ),
                ),
                (
                    "email",
                    models.EmailField(max_length=254, verbose_name="електронна пошта"),
                ),
                (
                    "role",
                    models.CharField(
                        choices=[
                            ("admin", "Адміністратор"),
                            ("teacher", "Викладач"),
                            ("student", "Студент"),
                        ],
                        default="student",
                        max_length=10,
                        verbose_name="роль",
                    ),
                ),
                (
                    "groups",
                    models.ManyToManyField(
                        blank=True,
                        help_text="The groups this user belongs to. A user will get all permissions granted to each of their groups.",
                        related_name="user_set",
                        related_query_name="user",
                        to="auth.group",
                        verbose_name="groups",
                    ),
                ),
                (
                    "user_permissions",
                    models.ManyToManyField(
                        blank=True,
                        help_text="Specific permissions for this user.",
                        related_name="user_set",
                        related_query_name="user",
                        to="auth.permission",
                        verbose_name="user permissions",
                    ),
                ),
            ],
            options={
                "verbose_name": "користувач",
                "verbose_name_plural": "користувачі",
                "db_table": "accounts_user",
            },
            managers=[
                ("objects", accounts.models.AccountUserManager()),
            ],
        ),
        migrations.CreateModel(
            name="TeacherProfile",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("first_name", models.CharField(max_length=150, verbose_name="ім'я")),
                (
                    "last_name",
                    models.CharField(max_length=150, verbose_name="прізвище"),
                ),
                (
                    "patronymic",
                    models.CharField(
                        blank=True, max_length=150, verbose_name="по батькові"
                    ),
                ),
                (
                    "position",
                    models.CharField(blank=True, max_length=150, verbose_name="посада"),
                ),
                (
                    "academic_degree",
                    models.CharField(
                        blank=True, max_length=150, verbose_name="науковий ступінь"
                    ),
                ),
                (
                    "user",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="teacher_profile",
                        to=settings.AUTH_USER_MODEL,
                        verbose_name="користувач",
                    ),
                ),
            ],
            options={
                "verbose_name": "профіль викладача",
                "verbose_name_plural": "профілі викладачів",
                "db_table": "accounts_teacherprofile",
            },
        ),
        migrations.CreateModel(
            name="StudentProfile",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("first_name", models.CharField(max_length=150, verbose_name="ім'я")),
                (
                    "last_name",
                    models.CharField(max_length=150, verbose_name="прізвище"),
                ),
                (
                    "patronymic",
                    models.CharField(
                        blank=True, max_length=150, verbose_name="по батькові"
                    ),
                ),
                (
                    "student_number",
                    models.CharField(
                        max_length=50,
                        unique=True,
                        verbose_name="номер студентського квитка",
                    ),
                ),
                (
                    "enrollment_year",
                    models.PositiveSmallIntegerField(verbose_name="рік вступу"),
                ),
                (
                    "user",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="student_profile",
                        to=settings.AUTH_USER_MODEL,
                        verbose_name="користувач",
                    ),
                ),
            ],
            options={
                "verbose_name": "профіль студента",
                "verbose_name_plural": "профілі студентів",
                "db_table": "accounts_studentprofile",
                "constraints": [
                    models.CheckConstraint(
                        condition=models.Q(("enrollment_year__gt", 0)),
                        name="student_enrollment_year_positive",
                    )
                ],
            },
        ),
    ]
