#!/usr/bin/env bash
# Створює датований PostgreSQL-дамп і видаляє резервні копії старші за 30 днів.
set -euo pipefail

ENV_FILE="${ENV_FILE:-/etc/gradebook.env}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/gradebook}"

if [[ ! -f "$ENV_FILE" ]]; then
    echo "Не знайдено файл змінних: $ENV_FILE" >&2
    exit 1
fi

set -a
source "$ENV_FILE"
set +a

: "${POSTGRES_DB:?Не задано POSTGRES_DB}"
: "${POSTGRES_USER:?Не задано POSTGRES_USER}"
: "${POSTGRES_PASSWORD:?Не задано POSTGRES_PASSWORD}"
: "${POSTGRES_HOST:?Не задано POSTGRES_HOST}"
: "${POSTGRES_PORT:?Не задано POSTGRES_PORT}"

install -d -m 0750 "$BACKUP_DIR"
timestamp="$(date +'%Y-%m-%d_%H-%M-%S')"
backup_file="$BACKUP_DIR/gradebook_$timestamp.dump"

PGPASSWORD="$POSTGRES_PASSWORD" pg_dump \
    --host="$POSTGRES_HOST" \
    --port="$POSTGRES_PORT" \
    --username="$POSTGRES_USER" \
    --format=custom \
    --file="$backup_file" \
    "$POSTGRES_DB"

find "$BACKUP_DIR" -type f -name 'gradebook_*.dump' -mtime +30 -delete
echo "Резервну копію створено: $backup_file"
