# Журнал навчальних досягнень

Проєкт містить каркас Django, акаунти, академічну структуру та повний журнал оцінювання: навчальні роботи, оцінки, історію змін, поточні й підсумкові результати та Excel-відомість.

## Локальний запуск

Команди виконуються з папки `code/`. Віртуальне середовище зберігається поруч із нею, щоб не потрапити до архіву застосунку.

```powershell
python -m venv ..\.venv
..\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Відредагуйте `.env`, а потім завантажте його значення у поточну PowerShell-сесію:

```powershell
Get-Content .env | Where-Object { $_ -match '^[^#].+=' } | ForEach-Object {
    $name, $value = $_ -split '=', 2
    Set-Item -Path "Env:$name" -Value $value
}
```

Файл не завантажується Django автоматично: production також передає ці змінні через systemd `EnvironmentFile`. Для локального SQLite змініть один рядок:

```powershell
$env:DJANGO_DB_ENGINE='sqlite'
```

Для PostgreSQL залиште `DJANGO_DB_ENGINE=postgresql` і задайте `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_HOST`, `POSTGRES_PORT`.

```powershell
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```

`seed_demo` можна запускати повторно: команда оновлює той самий набір і не створює дублікатів. Вона виводить демонстраційні логіни й паролі. Для власних даних замість неї створіть першого адміністратора через `python manage.py createsuperuser`.

Академічний довідник доступний у `/academics/specialities/`, курси — у `/academics/courses/`, а студентські оцінки — у `/grading/student/`.

## Поточна структура даних

```mermaid
erDiagram
    User ||--o| StudentProfile : "роль студента"
    User ||--o| TeacherProfile : "роль викладача"
    Speciality ||--o{ StudyGroup : "містить"
    StudyGroup ||--o{ StudentProfile : "поточна група"
    TeacherProfile ||--o{ Course : "викладає"
    Course }o--o{ StudyGroup : "призначений групам"
    Course ||--o{ Enrollment : "має"
    StudentProfile ||--o{ Enrollment : "зарахований"
    StudyGroup ||--o{ Enrollment : "знімок групи"
    Course ||--o{ Assignment : "містить роботи"
    Enrollment ||--o{ Grade : "отримує оцінки"
    Assignment ||--o{ Grade : "оцінюється"
    Grade ||--o{ GradeHistory : "має аудит"
    User ||--o{ GradeHistory : "змінює"
```

Зараз є десять прикладних моделей і автоматична M2M-таблиця `academics_course_groups`, тобто одинадцять доменних таблиць. До них додаються стандартні таблиці Django для міграцій, сесій, дозволів і груп доступу.

## Розрахунок результату

- Поточний бал нормується за вагами вже оцінених робіт.
- Підсумковий прогноз враховує ваги всіх робіт, а неоцінені роботи дають нульовий внесок.
- Обидва результати рахуються через `Decimal` і математично округлюються до цілого.
- ECTS та національна оцінка визначаються за шкалою з `DECISIONS_GRADING.md`.

Excel-відомість формує один аркуш на курс і використовує ті самі дані, формулу та права доступу, що й вебжурнал.

## Тести

Основна база даних — PostgreSQL. Для локальної перевірки без запущеного PostgreSQL дозволений явний SQLite-режим:

```powershell
$env:DJANGO_SECRET_KEY='test-key'
$env:DJANGO_DB_ENGINE='sqlite'
$env:DJANGO_DEBUG='true'
python manage.py migrate
python manage.py test
$env:DJANGO_DEBUG='false'
python manage.py test
```

Тести запускаються і з `DEBUG=true`, і з `DEBUG=false`. Під час команди `test` SSL-редірект вимкнений, але production-перевірка та звичайний запуск із `DEBUG=false` зберігають secure cookies, перенаправлення на HTTPS і HSTS.

## Production-розгортання на Ubuntu

Приклад розрахований на `/var/www/gradebook/code`, PostgreSQL 16, користувача процесу `www-data` і домен `gradebook.example.com`. Перед використанням замініть домен та шляхи у файлах `deploy/`.

1. Встановіть Python, PostgreSQL, Nginx і Certbot; створіть базу та окремого користувача PostgreSQL.
2. Розмістіть код у `/var/www/gradebook/code`, а віртуальне середовище — у `/var/www/gradebook/.venv`.
3. Встановіть залежності:

   ```bash
   /var/www/gradebook/.venv/bin/pip install -r /var/www/gradebook/code/requirements.txt
   ```

4. Створіть `/etc/gradebook.env` з такими змінними:

   ```env
   DJANGO_SECRET_KEY=довгий-випадковий-секрет
   DJANGO_DEBUG=false
   DJANGO_ALLOWED_HOSTS=gradebook.example.com
   DJANGO_DB_ENGINE=postgresql
   POSTGRES_DB=gradebook
   POSTGRES_USER=gradebook
   POSTGRES_PASSWORD=надійний-пароль
   POSTGRES_HOST=127.0.0.1
   POSTGRES_PORT=5432
   ```

   Обмежте доступ: `sudo chown root:www-data /etc/gradebook.env && sudo chmod 640 /etc/gradebook.env`.

5. Застосуйте схему й зберіть статику:

   ```bash
   cd /var/www/gradebook/code
   set -a; source /etc/gradebook.env; set +a
   ../.venv/bin/python manage.py migrate
   ../.venv/bin/python manage.py collectstatic --noinput
   ../.venv/bin/python manage.py createsuperuser
   ```

6. Встановіть і запустіть Gunicorn:

   ```bash
   sudo cp deploy/gunicorn.service /etc/systemd/system/gradebook.service
   sudo systemctl daemon-reload
   sudo systemctl enable --now gradebook
   sudo systemctl status gradebook
   ```

7. Отримайте сертифікат командою `sudo certbot certonly --standalone -d gradebook.example.com` (на час перевірки Certbot порт 80 має бути вільним). Потім скопіюйте `deploy/nginx.conf` до `/etc/nginx/sites-available/gradebook`, створіть посилання в `sites-enabled` і виконайте `sudo nginx -t && sudo systemctl reload nginx`.
8. Зробіть скрипти виконуваними й додайте щоденний запуск `backup_db.sh` через cron. Дампи зберігаються 30 днів; орієнтовні RPO — 24 години, RTO — кілька годин. Періодично перевіряйте відновлення через `restore_db.sh` на окремій тестовій базі.

## Сценарій демонстрації до 30 секунд

1. Виконайте `python manage.py seed_demo` і запустіть сервер.
2. Увійдіть як `demo_teacher1` паролем, показаним командою.
3. Відкрийте «Курси» → «Тестування програмного забезпечення» → «Відкрити журнал».
4. У рядку «Мельник Андрій» відкрийте оцінку за першою лабораторною, змініть бал і збережіть. Покажіть поточний, підсумковий бал та ECTS у таблиці.
5. Вийдіть і увійдіть як `demo_student1` тим самим демонстраційним паролем.
6. Відкрийте «Мої оцінки» та покажіть новий бал, прогноз, ECTS і анонімне середнє групи.
