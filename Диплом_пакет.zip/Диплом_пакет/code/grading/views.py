from decimal import Decimal, ROUND_HALF_UP

from django.contrib import messages
from django.db.models import Prefetch
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from academics.models import Course, Enrollment
from accounts.models import User
from accounts.permissions import role_required

from .calculations import calculate_score
from .forms import AssignmentForm, GradeForm
from .models import Assignment, Grade, delete_grade, save_grade
from .reports import build_course_workbook
from .scale import ects_grade


def grading_courses_for_user(user):
    """Обмежує журнал і відомість тим самим набором дозволених курсів."""
    courses = Course.objects.select_related("teacher__user").prefetch_related("groups")
    if user.role == User.Role.ADMIN:
        return courses
    if user.role == User.Role.TEACHER:
        return courses.filter(teacher__user=user)
    return courses.none()


def journal_rows(course, assignments):
    enrollments = course.enrollments.filter(is_active=True).select_related(
        "student__user",
        "study_group",
    ).prefetch_related(
        Prefetch("grades", queryset=Grade.objects.select_related("assignment"))
    )
    rows = []
    for enrollment in enrollments:
        grades = list(enrollment.grades.all())
        grades_by_assignment = {grade.assignment_id: grade for grade in grades}
        final_score = calculate_score(assignments, grades, mode="final")
        letter, national = ects_grade(final_score)
        rows.append(
            {
                "enrollment": enrollment,
                "cells": [
                    {
                        "assignment": assignment,
                        "grade": grades_by_assignment.get(assignment.pk),
                    }
                    for assignment in assignments
                ],
                "current_score": calculate_score(assignments, grades, mode="current"),
                "final_score": final_score,
                "letter": letter,
                "national": national,
            }
        )
    return rows


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def journal(request, course_pk):
    course = get_object_or_404(grading_courses_for_user(request.user), pk=course_pk)
    assignments = list(course.assignments.all())
    return render(
        request,
        "grading/journal.html",
        {
            "course": course,
            "assignments": assignments,
            "rows": journal_rows(course, assignments),
        },
    )


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def assignment_create(request, course_pk):
    course = get_object_or_404(grading_courses_for_user(request.user), pk=course_pk)
    form = AssignmentForm(request.POST or None, course=course)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Навчальну роботу створено.")
        return redirect("grading:journal", course_pk=course.pk)
    return render(
        request,
        "grading/assignment_form.html",
        {"form": form, "course": course, "title": "Нова навчальна робота"},
    )


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def assignment_update(request, course_pk, pk):
    course = get_object_or_404(grading_courses_for_user(request.user), pk=course_pk)
    assignment = get_object_or_404(course.assignments, pk=pk)
    form = AssignmentForm(
        request.POST or None,
        instance=assignment,
        course=course,
    )
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Навчальну роботу оновлено.")
        return redirect("grading:journal", course_pk=course.pk)
    return render(
        request,
        "grading/assignment_form.html",
        {"form": form, "course": course, "title": "Редагування роботи"},
    )


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def grade_update(request, course_pk, enrollment_pk, assignment_pk):
    course = get_object_or_404(grading_courses_for_user(request.user), pk=course_pk)
    enrollment = get_object_or_404(
        course.enrollments.select_related("student"),
        pk=enrollment_pk,
        is_active=True,
    )
    assignment = get_object_or_404(course.assignments, pk=assignment_pk)
    grade = Grade.objects.filter(
        enrollment=enrollment,
        assignment=assignment,
    ).first()
    instance = grade or Grade(enrollment=enrollment, assignment=assignment)
    form = GradeForm(request.POST or None, instance=instance)
    if request.method == "POST" and form.is_valid():
        save_grade(form.save(commit=False), request.user)
        messages.success(request, "Оцінку збережено.")
        return redirect("grading:journal", course_pk=course.pk)
    return render(
        request,
        "grading/grade_form.html",
        {
            "form": form,
            "course": course,
            "enrollment": enrollment,
            "assignment": assignment,
            "grade": grade,
        },
    )


@require_POST
@role_required(User.Role.ADMIN, User.Role.TEACHER)
def grade_delete(request, course_pk, enrollment_pk, assignment_pk):
    course = get_object_or_404(grading_courses_for_user(request.user), pk=course_pk)
    grade = get_object_or_404(
        Grade.objects.select_related("enrollment", "assignment"),
        enrollment_id=enrollment_pk,
        assignment_id=assignment_pk,
        enrollment__course=course,
        assignment__course=course,
    )
    delete_grade(grade, request.user)
    messages.success(request, "Оцінку видалено, історію збережено.")
    return redirect("grading:journal", course_pk=course.pk)


def group_average(course, study_group, assignments):
    enrollments = Enrollment.objects.filter(
        course=course,
        study_group=study_group,
        is_active=True,
    ).prefetch_related("grades")
    scores = [
        calculate_score(assignments, enrollment.grades.all(), mode="final")
        for enrollment in enrollments
    ]
    if not scores:
        return Decimal("0")
    average = sum(scores, Decimal("0")) / Decimal(len(scores))
    return average.quantize(Decimal("1"), rounding=ROUND_HALF_UP)


@role_required(User.Role.STUDENT)
def student_dashboard(request):
    student = request.user.student_profile
    enrollments = Enrollment.objects.filter(student=student).select_related(
        "course__teacher",
        "study_group",
    ).prefetch_related(
        Prefetch("grades", queryset=Grade.objects.select_related("assignment")),
        "course__assignments",
    )
    courses = []
    for enrollment in enrollments:
        assignments = list(enrollment.course.assignments.all())
        grades = list(enrollment.grades.all())
        grades_by_assignment = {grade.assignment_id: grade for grade in grades}
        final_score = calculate_score(assignments, grades, mode="final")
        letter, national = ects_grade(final_score)
        courses.append(
            {
                "enrollment": enrollment,
                "works": [
                    {
                        "assignment": assignment,
                        "grade": grades_by_assignment.get(assignment.pk),
                    }
                    for assignment in assignments
                ],
                "current_score": calculate_score(assignments, grades, mode="current"),
                "final_score": final_score,
                "letter": letter,
                "national": national,
                "group_average": group_average(
                    enrollment.course,
                    enrollment.study_group,
                    assignments,
                ),
            }
        )
    return render(request, "grading/student_dashboard.html", {"courses": courses})


@role_required(User.Role.ADMIN, User.Role.TEACHER)
def course_report(request, course_pk):
    course = get_object_or_404(grading_courses_for_user(request.user), pk=course_pk)
    content = build_course_workbook(course)
    response = HttpResponse(
        content,
        content_type=(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ),
    )
    response["Content-Disposition"] = (
        f'attachment; filename="course_{course.pk}_statement.xlsx"'
    )
    return response
