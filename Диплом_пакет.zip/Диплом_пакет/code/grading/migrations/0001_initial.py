import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        (
            "academics",
            "0002_course_enrollment_course_course_year_semester_idx_and_more",
        ),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Assignment",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "type",
                    models.CharField(
                        choices=[
                            ("lab", "Лабораторна робота"),
                            ("practice", "Практична робота"),
                            ("test", "Контрольна робота"),
                            ("exam", "Іспит"),
                            ("coursework", "Курсова робота"),
                        ],
                        max_length=12,
                        verbose_name="тип",
                    ),
                ),
                ("number", models.PositiveSmallIntegerField(verbose_name="номер")),
                ("title", models.CharField(max_length=255, verbose_name="назва")),
                (
                    "max_score",
                    models.DecimalField(
                        decimal_places=2, max_digits=7, verbose_name="максимальний бал"
                    ),
                ),
                (
                    "weight",
                    models.DecimalField(
                        decimal_places=2, max_digits=7, verbose_name="вага"
                    ),
                ),
                ("date", models.DateField(blank=True, null=True, verbose_name="дата")),
                (
                    "course",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="assignments",
                        to="academics.course",
                        verbose_name="курс",
                    ),
                ),
            ],
            options={
                "verbose_name": "навчальна робота",
                "verbose_name_plural": "навчальні роботи",
                "db_table": "grading_assignment",
                "ordering": ("type", "number"),
            },
        ),
        migrations.CreateModel(
            name="Grade",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "score",
                    models.DecimalField(
                        decimal_places=2, max_digits=7, verbose_name="бал"
                    ),
                ),
                ("comment", models.TextField(blank=True, verbose_name="коментар")),
                (
                    "created_at",
                    models.DateTimeField(auto_now_add=True, verbose_name="створено"),
                ),
                (
                    "updated_at",
                    models.DateTimeField(auto_now=True, verbose_name="оновлено"),
                ),
                (
                    "assignment",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="grades",
                        to="grading.assignment",
                        verbose_name="навчальна робота",
                    ),
                ),
                (
                    "enrollment",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="grades",
                        to="academics.enrollment",
                        verbose_name="зарахування",
                    ),
                ),
            ],
            options={
                "verbose_name": "оцінка",
                "verbose_name_plural": "оцінки",
                "db_table": "grading_grade",
                "ordering": ("assignment__type", "assignment__number"),
            },
        ),
        migrations.CreateModel(
            name="GradeHistory",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "action",
                    models.CharField(
                        choices=[
                            ("create", "Створення"),
                            ("update", "Оновлення"),
                            ("delete", "Видалення"),
                        ],
                        max_length=6,
                        verbose_name="дія",
                    ),
                ),
                (
                    "old_score",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=7,
                        null=True,
                        verbose_name="попередній бал",
                    ),
                ),
                (
                    "new_score",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=7,
                        null=True,
                        verbose_name="новий бал",
                    ),
                ),
                (
                    "old_comment",
                    models.TextField(
                        blank=True, null=True, verbose_name="попередній коментар"
                    ),
                ),
                (
                    "new_comment",
                    models.TextField(
                        blank=True, null=True, verbose_name="новий коментар"
                    ),
                ),
                (
                    "changed_at",
                    models.DateTimeField(auto_now_add=True, verbose_name="змінено"),
                ),
                (
                    "assignment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="grade_history",
                        to="grading.assignment",
                        verbose_name="навчальна робота",
                    ),
                ),
                (
                    "changed_by",
                    models.ForeignKey(
                        db_index=False,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="grade_changes",
                        to=settings.AUTH_USER_MODEL,
                        verbose_name="хто змінив",
                    ),
                ),
                (
                    "enrollment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="grade_history",
                        to="academics.enrollment",
                        verbose_name="зарахування",
                    ),
                ),
                (
                    "grade",
                    models.ForeignKey(
                        blank=True,
                        db_index=False,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="history_entries",
                        to="grading.grade",
                        verbose_name="оцінка",
                    ),
                ),
            ],
            options={
                "verbose_name": "історія оцінки",
                "verbose_name_plural": "історія оцінок",
                "db_table": "grading_gradehistory",
                "ordering": ("-changed_at",),
            },
        ),
        migrations.AddIndex(
            model_name="assignment",
            index=models.Index(
                fields=["course", "date"], name="assignment_course_date_idx"
            ),
        ),
        migrations.AddConstraint(
            model_name="assignment",
            constraint=models.CheckConstraint(
                condition=models.Q(("number__gte", 1)),
                name="assignment_number_positive",
            ),
        ),
        migrations.AddConstraint(
            model_name="assignment",
            constraint=models.CheckConstraint(
                condition=models.Q(("max_score__gt", 0)),
                name="assignment_max_score_positive",
            ),
        ),
        migrations.AddConstraint(
            model_name="assignment",
            constraint=models.CheckConstraint(
                condition=models.Q(("weight__gt", 0)), name="assignment_weight_positive"
            ),
        ),
        migrations.AddConstraint(
            model_name="assignment",
            constraint=models.UniqueConstraint(
                fields=("course", "type", "number"),
                name="unique_course_assignment_type_number",
            ),
        ),
        migrations.AddIndex(
            model_name="grade",
            index=models.Index(fields=["enrollment"], name="grade_enrollment_idx"),
        ),
        migrations.AddIndex(
            model_name="grade",
            index=models.Index(fields=["assignment"], name="grade_assignment_idx"),
        ),
        migrations.AddConstraint(
            model_name="grade",
            constraint=models.CheckConstraint(
                condition=models.Q(("score__gte", 0)), name="grade_score_nonnegative"
            ),
        ),
        migrations.AddConstraint(
            model_name="grade",
            constraint=models.UniqueConstraint(
                fields=("enrollment", "assignment"),
                name="unique_enrollment_assignment_grade",
            ),
        ),
        migrations.AddIndex(
            model_name="gradehistory",
            index=models.Index(
                fields=["grade", "changed_at"], name="history_grade_changed_idx"
            ),
        ),
        migrations.AddIndex(
            model_name="gradehistory",
            index=models.Index(
                fields=["changed_by", "changed_at"], name="history_user_changed_idx"
            ),
        ),
    ]
