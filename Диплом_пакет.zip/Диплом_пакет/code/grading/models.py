from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models import Q


class Assignment(models.Model):
    class Type(models.TextChoices):
        LAB = "lab", "Лабораторна робота"
        PRACTICE = "practice", "Практична робота"
        TEST = "test", "Контрольна робота"
        EXAM = "exam", "Іспит"
        COURSEWORK = "coursework", "Курсова робота"

    course = models.ForeignKey(
        "academics.Course",
        on_delete=models.PROTECT,
        related_name="assignments",
        verbose_name="курс",
        db_index=False,
    )
    type = models.CharField("тип", max_length=12, choices=Type.choices)
    number = models.PositiveSmallIntegerField("номер")
    title = models.CharField("назва", max_length=255)
    max_score = models.DecimalField(
        "максимальний бал",
        max_digits=7,
        decimal_places=2,
    )
    weight = models.DecimalField(
        "вага",
        max_digits=7,
        decimal_places=2,
    )
    date = models.DateField("дата", blank=True, null=True)

    class Meta:
        db_table = "grading_assignment"
        ordering = ("type", "number")
        verbose_name = "навчальна робота"
        verbose_name_plural = "навчальні роботи"
        constraints = [
            models.CheckConstraint(
                condition=Q(number__gte=1),
                name="assignment_number_positive",
            ),
            models.CheckConstraint(
                condition=Q(max_score__gt=0),
                name="assignment_max_score_positive",
            ),
            models.CheckConstraint(
                condition=Q(weight__gt=0),
                name="assignment_weight_positive",
            ),
            models.UniqueConstraint(
                fields=("course", "type", "number"),
                name="unique_course_assignment_type_number",
            ),
        ]
        indexes = [
            models.Index(
                fields=("course", "date"),
                name="assignment_course_date_idx",
            )
        ]

    def __str__(self):
        return f"{self.get_type_display()} №{self.number}: {self.title}"

    def clean(self):
        if (
            self.pk
            and self.max_score is not None
            and self.grades.filter(score__gt=Decimal(str(self.max_score))).exists()
        ):
            raise ValidationError(
                {"max_score": "Максимум не може бути нижчим за наявну оцінку."}
            )


class GradeQuerySet(models.QuerySet):
    def bulk_create(self, *args, **kwargs):
        raise NotImplementedError("Масове створення оцінок заборонене.")

    def bulk_update(self, *args, **kwargs):
        raise NotImplementedError("Масове оновлення оцінок заборонене.")


class Grade(models.Model):
    enrollment = models.ForeignKey(
        "academics.Enrollment",
        on_delete=models.PROTECT,
        related_name="grades",
        verbose_name="зарахування",
        db_index=False,
    )
    assignment = models.ForeignKey(
        Assignment,
        on_delete=models.PROTECT,
        related_name="grades",
        verbose_name="навчальна робота",
        db_index=False,
    )
    score = models.DecimalField("бал", max_digits=7, decimal_places=2)
    comment = models.TextField("коментар", blank=True)
    created_at = models.DateTimeField("створено", auto_now_add=True)
    updated_at = models.DateTimeField("оновлено", auto_now=True)

    objects = GradeQuerySet.as_manager()

    class Meta:
        db_table = "grading_grade"
        ordering = ("assignment__type", "assignment__number")
        verbose_name = "оцінка"
        verbose_name_plural = "оцінки"
        constraints = [
            models.CheckConstraint(
                condition=Q(score__gte=0),
                name="grade_score_nonnegative",
            ),
            models.UniqueConstraint(
                fields=("enrollment", "assignment"),
                name="unique_enrollment_assignment_grade",
            ),
        ]
        indexes = [
            models.Index(fields=("enrollment",), name="grade_enrollment_idx"),
            models.Index(fields=("assignment",), name="grade_assignment_idx"),
        ]

    def clean(self):
        errors = {}
        if (
            self.enrollment_id
            and self.assignment_id
            and self.enrollment.course_id != self.assignment.course_id
        ):
            errors["assignment"] = "Робота та зарахування належать різним курсам."
        if (
            self.assignment_id
            and self.score is not None
            and self.score > Decimal(str(self.assignment.max_score))
        ):
            errors["score"] = "Бал не може перевищувати максимум роботи."
        if self.enrollment_id and not self.enrollment.is_active:
            errors["enrollment"] = "Не можна оцінювати неактивне зарахування."
        if errors:
            raise ValidationError(errors)

    def __str__(self):
        return f"{self.enrollment.student}: {self.assignment} — {self.score}"


class GradeHistory(models.Model):
    class Action(models.TextChoices):
        CREATE = "create", "Створення"
        UPDATE = "update", "Оновлення"
        DELETE = "delete", "Видалення"

    grade = models.ForeignKey(
        Grade,
        on_delete=models.SET_NULL,
        related_name="history_entries",
        verbose_name="оцінка",
        blank=True,
        null=True,
        db_index=False,
    )
    enrollment = models.ForeignKey(
        "academics.Enrollment",
        on_delete=models.PROTECT,
        related_name="grade_history",
        verbose_name="зарахування",
    )
    assignment = models.ForeignKey(
        Assignment,
        on_delete=models.PROTECT,
        related_name="grade_history",
        verbose_name="навчальна робота",
    )
    action = models.CharField("дія", max_length=6, choices=Action.choices)
    old_score = models.DecimalField(
        "попередній бал",
        max_digits=7,
        decimal_places=2,
        blank=True,
        null=True,
    )
    new_score = models.DecimalField(
        "новий бал",
        max_digits=7,
        decimal_places=2,
        blank=True,
        null=True,
    )
    old_comment = models.TextField("попередній коментар", blank=True, null=True)
    new_comment = models.TextField("новий коментар", blank=True, null=True)
    changed_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.PROTECT,
        related_name="grade_changes",
        verbose_name="хто змінив",
        db_index=False,
    )
    changed_at = models.DateTimeField("змінено", auto_now_add=True)

    class Meta:
        db_table = "grading_gradehistory"
        ordering = ("-changed_at",)
        verbose_name = "історія оцінки"
        verbose_name_plural = "історія оцінок"
        indexes = [
            models.Index(
                fields=("grade", "changed_at"),
                name="history_grade_changed_idx",
            ),
            models.Index(
                fields=("changed_by", "changed_at"),
                name="history_user_changed_idx",
            ),
        ]

    def __str__(self):
        return f"{self.get_action_display()}: {self.assignment}"


@transaction.atomic
def save_grade(grade, changed_by):
    """Зберігає оцінку та аудит разом, щоб вони не могли розійтися."""
    previous = None
    if grade.pk:
        previous = Grade.objects.select_for_update().filter(pk=grade.pk).first()

    grade.full_clean()
    grade.save()
    GradeHistory.objects.create(
        grade=grade,
        enrollment=grade.enrollment,
        assignment=grade.assignment,
        action=(
            GradeHistory.Action.UPDATE
            if previous
            else GradeHistory.Action.CREATE
        ),
        old_score=previous.score if previous else None,
        new_score=grade.score,
        old_comment=previous.comment if previous else None,
        new_comment=grade.comment,
        changed_by=changed_by,
    )
    return grade


@transaction.atomic
def delete_grade(grade, changed_by):
    """Видаляє оцінку лише разом із незмінним записом її попереднього стану."""
    stored_grade = Grade.objects.select_for_update().get(pk=grade.pk)
    GradeHistory.objects.create(
        grade=stored_grade,
        enrollment=stored_grade.enrollment,
        assignment=stored_grade.assignment,
        action=GradeHistory.Action.DELETE,
        old_score=stored_grade.score,
        new_score=None,
        old_comment=stored_grade.comment,
        new_comment=None,
        changed_by=changed_by,
    )
    stored_grade.delete()
