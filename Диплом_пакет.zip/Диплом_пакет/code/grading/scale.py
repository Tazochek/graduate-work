from decimal import Decimal, ROUND_HALF_UP


def ects_grade(points):
    """Перетворює 100-бальний результат на ECTS і національну оцінку."""
    rounded = Decimal(str(points)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    if not Decimal("0") <= rounded <= Decimal("100"):
        raise ValueError("Бал має бути в межах від 0 до 100.")
    if rounded >= 90:
        return "A", "відмінно (5)"
    if rounded >= 82:
        return "B", "добре (4)"
    if rounded >= 74:
        return "C", "добре (4)"
    if rounded >= 64:
        return "D", "задовільно (3)"
    if rounded >= 60:
        return "E", "задовільно (3)"
    if rounded >= 35:
        return "FX", "незадовільно (2), з правом перескладання"
    return "F", "незадовільно (2), повторне вивчення"
