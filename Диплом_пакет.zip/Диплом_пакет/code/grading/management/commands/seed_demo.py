from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from django.core.management.base import BaseCommand
from django.db import transaction

from academics.models import Course, Enrollment, Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User
from grading.models import Assignment, Grade, save_grade


DEMO_PASSWORD = "DemoPass123!"


class Command(BaseCommand):
    help = "Створює ідемпотентний набір даних для демонстрації застосунку."

    @transaction.atomic
    def handle(self, *args, **options):
        speciality = self.ensure_speciality()
        groups = self.ensure_groups(speciality)
        admin = self.ensure_admin()
        teachers = self.ensure_teachers()
        students = self.ensure_students(groups)
        courses = self.ensure_courses(teachers, groups)
        self.ensure_enrollments(courses, students)
        assignments = self.ensure_assignments(courses)
        self.ensure_grades(courses, assignments, teachers)

        self.stdout.write(self.style.SUCCESS("Демонстраційні дані готові."))
        self.stdout.write(f"Адміністратор: {admin.username} / {DEMO_PASSWORD}")
        for teacher in teachers:
            self.stdout.write(
                f"Викладач: {teacher.user.username} / {DEMO_PASSWORD}"
            )
        for student in students:
            self.stdout.write(
                f"Студент: {student.user.username} / {DEMO_PASSWORD}"
            )
        self.stdout.write(
            "Для короткого відео використайте demo_teacher1 і demo_student1."
        )

    def ensure_password(self, user):
        if not user.check_password(DEMO_PASSWORD):
            user.set_password(DEMO_PASSWORD)
            user.save(update_fields=("password",))

    def ensure_admin(self):
        user, _ = User.objects.update_or_create(
            username="demo_admin",
            defaults={
                "email": "demo_admin@example.com",
                "role": User.Role.ADMIN,
                "is_staff": True,
                "is_active": True,
            },
        )
        self.ensure_password(user)
        return user

    def ensure_teachers(self):
        data = (
            ("demo_teacher1", "Олена", "Коваль", "Доцент"),
            ("demo_teacher2", "Олег", "Шевченко", "Професор"),
            ("demo_teacher3", "Наталія", "Бондаренко", "Старший викладач"),
        )
        teachers = []
        for username, first_name, last_name, position in data:
            user, _ = User.objects.update_or_create(
                username=username,
                defaults={
                    "email": f"{username}@example.com",
                    "role": User.Role.TEACHER,
                    "is_staff": False,
                    "is_active": True,
                },
            )
            self.ensure_password(user)
            profile, _ = TeacherProfile.objects.update_or_create(
                user=user,
                defaults={
                    "first_name": first_name,
                    "last_name": last_name,
                    "patronymic": "",
                    "position": position,
                    "academic_degree": "",
                },
            )
            teachers.append(profile)
        return teachers

    def ensure_speciality(self):
        speciality, _ = Speciality.objects.update_or_create(
            code="121",
            defaults={"name": "Інженерія програмного забезпечення"},
        )
        return speciality

    def ensure_groups(self, speciality):
        groups = []
        for name in ("ПЗПІ-25-1", "ПЗПІ-25-2"):
            group, _ = StudyGroup.objects.update_or_create(
                name=name,
                defaults={"speciality": speciality, "admission_year": 2025},
            )
            groups.append(group)
        return groups

    def ensure_students(self, groups):
        names = (
            ("Андрій", "Мельник"),
            ("Ірина", "Бондар"),
            ("Максим", "Кравченко"),
            ("Софія", "Ткаченко"),
            ("Олександр", "Ковальчук"),
            ("Марія", "Шевчук"),
            ("Дмитро", "Лисенко"),
            ("Анна", "Романенко"),
        )
        students = []
        for index, (first_name, last_name) in enumerate(names, start=1):
            username = f"demo_student{index}"
            group = groups[0] if index <= 4 else groups[1]
            user, _ = User.objects.update_or_create(
                username=username,
                defaults={
                    "email": f"{username}@example.com",
                    "role": User.Role.STUDENT,
                    "is_staff": False,
                    "is_active": True,
                },
            )
            self.ensure_password(user)
            profile, _ = StudentProfile.objects.update_or_create(
                user=user,
                defaults={
                    "first_name": first_name,
                    "last_name": last_name,
                    "patronymic": "",
                    "student_number": f"DEMO-{index:03d}",
                    "enrollment_year": 2025,
                    "current_group": group,
                },
            )
            students.append(profile)
        return students

    def ensure_courses(self, teachers, groups):
        data = (
            {
                "key": "testing",
                "title": "Тестування програмного забезпечення",
                "description": "Методи забезпечення якості програмних систем.",
                "credits": 5,
                "semester": 1,
                "teacher": teachers[0],
                "groups": groups,
            },
            {
                "key": "databases",
                "title": "Бази даних",
                "description": "Проєктування та використання реляційних баз даних.",
                "credits": 5,
                "semester": 1,
                "teacher": teachers[1],
                "groups": groups,
            },
            {
                "key": "architecture",
                "title": "Архітектура програмного забезпечення",
                "description": "Архітектурні стилі та проєктування застосунків.",
                "credits": 4,
                "semester": 2,
                "teacher": teachers[2],
                "groups": [groups[0]],
            },
        )
        courses = {}
        for item in data:
            course, _ = Course.objects.update_or_create(
                title=item["title"],
                academic_year="2025-2026",
                semester=item["semester"],
                defaults={
                    "description": item["description"],
                    "credits": item["credits"],
                    "teacher": item["teacher"],
                },
            )
            course.groups.set(item["groups"])
            courses[item["key"]] = course
        return courses

    def ensure_enrollments(self, courses, students):
        for key, course in courses.items():
            course_students = students[:4] if key == "architecture" else students
            for student in course_students:
                Enrollment.objects.update_or_create(
                    course=course,
                    student=student,
                    defaults={
                        "study_group": student.current_group,
                        "is_active": True,
                    },
                )

    def ensure_assignments(self, courses):
        data = {
            "testing": (
                (Assignment.Type.LAB, 1, "Тест-дизайн", "10", "15", date(2025, 9, 20)),
                (Assignment.Type.LAB, 2, "Модульне тестування", "10", "15", date(2025, 10, 10)),
                (Assignment.Type.PRACTICE, 1, "Автоматизація тестів", "20", "20", date(2025, 11, 1)),
                (Assignment.Type.TEST, 1, "Модульний контроль", "20", "20", date(2025, 11, 20)),
                (Assignment.Type.EXAM, 1, "Іспит", "100", "30", date(2026, 1, 15)),
            ),
            "databases": (
                (Assignment.Type.LAB, 1, "Проєктування схеми", "20", "20", date(2025, 9, 25)),
                (Assignment.Type.LAB, 2, "SQL-запити", "20", "20", date(2025, 10, 20)),
                (Assignment.Type.TEST, 1, "Нормалізація даних", "20", "20", date(2025, 11, 15)),
                (Assignment.Type.EXAM, 1, "Іспит", "100", "40", date(2026, 1, 18)),
            ),
            "architecture": (
                (Assignment.Type.PRACTICE, 1, "Архітектурні стилі", "20", "20", date(2026, 2, 20)),
                (Assignment.Type.PRACTICE, 2, "UML-моделювання", "20", "20", date(2026, 3, 15)),
                (Assignment.Type.COURSEWORK, 1, "Архітектура застосунку", "30", "30", date(2026, 4, 20)),
                (Assignment.Type.EXAM, 1, "Іспит", "100", "30", date(2026, 6, 10)),
            ),
        }
        assignments = {}
        for key, specs in data.items():
            assignments[key] = []
            for assignment_type, number, title, maximum, weight, work_date in specs:
                assignment, _ = Assignment.objects.update_or_create(
                    course=courses[key],
                    type=assignment_type,
                    number=number,
                    defaults={
                        "title": title,
                        "max_score": maximum,
                        "weight": weight,
                        "date": work_date,
                    },
                )
                assignments[key].append(assignment)
        return assignments

    def ensure_grades(self, courses, assignments, teachers):
        graded_limits = {
            "testing": (8, 6, 4, 2, 0),
            "databases": (8, 5, 3, 0),
            "architecture": (4, 2, 1, 0),
        }
        teacher_by_course = {
            "testing": teachers[0].user,
            "databases": teachers[1].user,
            "architecture": teachers[2].user,
        }
        for key, course in courses.items():
            enrollments = list(
                course.enrollments.select_related("student").order_by(
                    "student__student_number"
                )
            )
            for assignment_index, assignment in enumerate(assignments[key]):
                limit = graded_limits[key][assignment_index]
                for student_index, enrollment in enumerate(enrollments[:limit]):
                    ratio = Decimal("0.65") + Decimal(
                        str((student_index + assignment_index) % 4)
                    ) * Decimal("0.10")
                    score = (
                        Decimal(str(assignment.max_score)) * ratio
                    ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    comment = "Демонстраційна оцінка"
                    grade = Grade.objects.filter(
                        enrollment=enrollment,
                        assignment=assignment,
                    ).first()
                    if grade is None:
                        save_grade(
                            Grade(
                                enrollment=enrollment,
                                assignment=assignment,
                                score=score,
                                comment=comment,
                            ),
                            teacher_by_course[key],
                        )
                    elif grade.score != score or grade.comment != comment:
                        grade.score = score
                        grade.comment = comment
                        save_grade(grade, teacher_by_course[key])
