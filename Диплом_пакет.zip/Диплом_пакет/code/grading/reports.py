from datetime import date
from io import BytesIO

from django.db.models import Prefetch
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.utils import get_column_letter

from .calculations import calculate_score
from .models import Grade
from .scale import ects_grade


def student_full_name(student):
    parts = [student.last_name, student.first_name, student.patronymic]
    return " ".join(part for part in parts if part)


def build_course_workbook(course):
    """Будує одну відомість з тих самих оцінок і формули, що й журнал."""
    assignments = list(course.assignments.all())
    enrollments = list(
        course.enrollments.filter(is_active=True).select_related(
            "student",
            "study_group",
        ).prefetch_related(
            Prefetch("grades", queryset=Grade.objects.select_related("assignment"))
        )
    )

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Відомість"
    total_columns = 7 + len(assignments)

    heading_rows = (
        "Харківський національний університет радіоелектроніки",
        "Кафедра програмної інженерії",
        f"Курс: {course.title}",
        f"Викладач: {course.teacher}",
        f"Навчальний рік: {course.academic_year}; семестр: {course.semester}",
        "Групи: " + ", ".join(group.name for group in course.groups.all()),
        f"Дата формування: {date.today().strftime('%d.%m.%Y')}",
    )
    for row_number, text in enumerate(heading_rows, start=1):
        worksheet.merge_cells(
            start_row=row_number,
            start_column=1,
            end_row=row_number,
            end_column=total_columns,
        )
        cell = worksheet.cell(row=row_number, column=1, value=text)
        cell.alignment = Alignment(horizontal="center")
        if row_number <= 2:
            cell.font = Font(bold=True)

    header_row = 9
    headers = ["№", "ПІБ", "№ залікової"]
    headers.extend(
        f"{assignment.get_type_display()} №{assignment.number}"
        for assignment in assignments
    )
    headers.extend(["Підсумковий бал", "ECTS", "Національна", "Підпис"])

    thin = Side(style="thin", color="808080")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for column, header in enumerate(headers, start=1):
        cell = worksheet.cell(row=header_row, column=column, value=header)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border

    for number, enrollment in enumerate(enrollments, start=1):
        row = header_row + number
        grades = list(enrollment.grades.all())
        grades_by_assignment = {grade.assignment_id: grade for grade in grades}
        values = [
            number,
            student_full_name(enrollment.student),
            enrollment.student.student_number,
        ]
        values.extend(
            (
                float(grades_by_assignment[assignment.pk].score)
                if assignment.pk in grades_by_assignment
                else None
            )
            for assignment in assignments
        )
        final_score = calculate_score(assignments, grades, mode="final")
        letter, national = ects_grade(final_score)
        values.extend([int(final_score), letter, national, ""])
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            cell.border = border
            cell.alignment = Alignment(vertical="center", wrap_text=True)

    footer_row = header_row + len(enrollments) + 2
    worksheet.cell(
        row=footer_row,
        column=2,
        value=f"Викладач ____________ {course.teacher}",
    )
    worksheet.cell(
        row=footer_row + 1,
        column=2,
        value=f"Дата: {date.today().strftime('%d.%m.%Y')}",
    )

    worksheet.freeze_panes = f"A{header_row + 1}"
    worksheet.column_dimensions["A"].width = 6
    worksheet.column_dimensions["B"].width = 32
    worksheet.column_dimensions["C"].width = 16
    for column in range(4, total_columns + 1):
        worksheet.column_dimensions[get_column_letter(column)].width = 18

    output = BytesIO()
    workbook.save(output)
    return output.getvalue()
