from unittest.mock import patch

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from grading.models import (
    Assignment,
    Grade,
    GradeHistory,
    delete_grade,
    save_grade,
)

from .base import GradingTestCase


class AssignmentModelTests(GradingTestCase):
    def test_course_type_and_number_are_unique_together(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            Assignment.objects.create(
                course=self.course,
                type=Assignment.Type.LAB,
                number=1,
                title="Дублікат",
                max_score="10.00",
                weight="10.00",
            )

    def test_assignment_constraints_reject_invalid_numbers(self):
        invalid_values = (
            {"number": 0, "max_score": "10.00", "weight": "10.00"},
            {"number": 2, "max_score": "0.00", "weight": "10.00"},
            {"number": 3, "max_score": "10.00", "weight": "0.00"},
        )
        for index, values in enumerate(invalid_values, start=1):
            with self.subTest(values=values):
                with self.assertRaises(IntegrityError), transaction.atomic():
                    Assignment.objects.create(
                        course=self.course,
                        type=Assignment.Type.TEST,
                        title=f"Некоректна робота {index}",
                        **values,
                    )


class GradeModelTests(GradingTestCase):
    def test_grade_rejects_score_above_assignment_maximum(self):
        grade = Grade(
            enrollment=self.enrollment,
            assignment=self.assignment,
            score="10.01",
        )
        with self.assertRaises(ValidationError) as error:
            grade.full_clean()
        self.assertIn("score", error.exception.message_dict)

    def test_grade_rejects_assignment_from_another_course(self):
        grade = Grade(
            enrollment=self.enrollment,
            assignment=self.other_assignment,
            score="8.00",
        )
        with self.assertRaises(ValidationError) as error:
            grade.full_clean()
        self.assertIn("assignment", error.exception.message_dict)

    def test_grade_rejects_inactive_enrollment(self):
        self.enrollment.is_active = False
        grade = Grade(
            enrollment=self.enrollment,
            assignment=self.assignment,
            score="8.00",
        )
        with self.assertRaises(ValidationError) as error:
            grade.full_clean()
        self.assertIn("enrollment", error.exception.message_dict)

    def test_enrollment_and_assignment_are_unique_together(self):
        Grade.objects.create(
            enrollment=self.enrollment,
            assignment=self.assignment,
            score="8.00",
        )
        with self.assertRaises(IntegrityError), transaction.atomic():
            Grade.objects.create(
                enrollment=self.enrollment,
                assignment=self.assignment,
                score="9.00",
            )

    def test_bulk_grade_writes_are_forbidden(self):
        grade = Grade(
            enrollment=self.enrollment,
            assignment=self.assignment,
            score="8.00",
        )
        with self.assertRaises(NotImplementedError):
            Grade.objects.bulk_create([grade])

        saved_grade = Grade.objects.create(
            enrollment=self.enrollment,
            assignment=self.assignment,
            score="8.00",
        )
        saved_grade.score = "9.00"
        with self.assertRaises(NotImplementedError):
            Grade.objects.bulk_update([saved_grade], ["score"])


class GradeHistoryTests(GradingTestCase):
    def test_create_update_and_delete_write_history(self):
        grade = save_grade(
            Grade(
                enrollment=self.enrollment,
                assignment=self.assignment,
                score="8.00",
                comment="Перша спроба",
            ),
            self.teacher.user,
        )
        grade.score = "9.00"
        grade.comment = "Виправлено"
        save_grade(grade, self.teacher.user)
        delete_grade(grade, self.teacher.user)

        history = list(GradeHistory.objects.order_by("changed_at"))
        self.assertEqual(
            [entry.action for entry in history],
            [
                GradeHistory.Action.CREATE,
                GradeHistory.Action.UPDATE,
                GradeHistory.Action.DELETE,
            ],
        )
        self.assertEqual(history[1].old_score, 8)
        self.assertEqual(history[1].new_score, 9)
        self.assertIsNone(history[2].grade)

    def test_grade_rolls_back_when_history_write_fails(self):
        grade = Grade(
            enrollment=self.enrollment,
            assignment=self.assignment,
            score="8.00",
        )
        with patch(
            "grading.models.GradeHistory.objects.create",
            side_effect=RuntimeError("history error"),
        ):
            with self.assertRaises(RuntimeError):
                save_grade(grade, self.teacher.user)

        self.assertFalse(
            Grade.objects.filter(
                enrollment=self.enrollment,
                assignment=self.assignment,
            ).exists()
        )
