from io import StringIO

from django.core.management import call_command
from django.test import TestCase, override_settings

from academics.models import Course, Enrollment, Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User
from grading.models import Assignment, Grade, GradeHistory

@override_settings(
    PASSWORD_HASHERS=["django.contrib.auth.hashers.MD5PasswordHasher"]
)
class SeedDemoCommandTests(TestCase):
    def test_seed_demo_is_idempotent(self):
        output = StringIO()
        call_command("seed_demo", stdout=output)
        first_counts = self.demo_counts()

        call_command("seed_demo", stdout=output)
        second_counts = self.demo_counts()

        self.assertEqual(first_counts, second_counts)
        self.assertIn("demo_teacher1", output.getvalue())
        self.assertIn("demo_student1", output.getvalue())
        self.assertTrue(User.objects.get(username="demo_admin").check_password("DemoPass123!"))

    def demo_counts(self):
        return (
            User.objects.filter(username__startswith="demo_").count(),
            TeacherProfile.objects.filter(user__username__startswith="demo_").count(),
            StudentProfile.objects.filter(user__username__startswith="demo_").count(),
            Speciality.objects.filter(code="121").count(),
            StudyGroup.objects.filter(name__startswith="ПЗПІ-25-").count(),
            Course.objects.filter(academic_year="2025-2026").count(),
            Enrollment.objects.filter(course__academic_year="2025-2026").count(),
            Assignment.objects.filter(course__academic_year="2025-2026").count(),
            Grade.objects.filter(enrollment__course__academic_year="2025-2026").count(),
            GradeHistory.objects.filter(
                enrollment__course__academic_year="2025-2026"
            ).count(),
        )
