from django.test import TestCase

from academics.models import Course, Enrollment, Speciality, StudyGroup
from accounts.models import StudentProfile, TeacherProfile, User
from grading.models import Assignment


class GradingTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin_user = User.objects.create_user(
            username="grading-admin",
            email="grading-admin@example.com",
            password="StrongPass123!",
            role=User.Role.ADMIN,
            is_staff=True,
        )
        owner_user = User.objects.create_user(
            username="grading-teacher",
            email="grading-teacher@example.com",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )
        cls.teacher = TeacherProfile.objects.create(
            user=owner_user,
            first_name="Олена",
            last_name="Коваль",
        )
        other_user = User.objects.create_user(
            username="other-grading-teacher",
            email="other-grading-teacher@example.com",
            password="StrongPass123!",
            role=User.Role.TEACHER,
        )
        cls.other_teacher = TeacherProfile.objects.create(
            user=other_user,
            first_name="Олег",
            last_name="Шевченко",
        )

        speciality = Speciality.objects.create(
            code="121",
            name="Інженерія програмного забезпечення",
        )
        cls.study_group = StudyGroup.objects.create(
            name="ПЗПІ-25-1",
            speciality=speciality,
            admission_year=2025,
        )
        cls.other_group = StudyGroup.objects.create(
            name="ПЗПІ-25-2",
            speciality=speciality,
            admission_year=2025,
        )
        cls.student = cls.create_student(
            username="grading-student",
            number="G-001",
            first_name="Ірина",
            last_name="Мельник",
            group=cls.study_group,
        )
        cls.peer_student = cls.create_student(
            username="grading-peer",
            number="G-002",
            first_name="Марія",
            last_name="Бондар",
            group=cls.study_group,
        )
        cls.other_student = cls.create_student(
            username="other-grading-student",
            number="G-003",
            first_name="Анна",
            last_name="Ткаченко",
            group=cls.other_group,
        )

        cls.course = Course.objects.create(
            title="Тестування програмного забезпечення",
            credits=5,
            semester=1,
            academic_year="2025-2026",
            teacher=cls.teacher,
        )
        cls.course.groups.add(cls.study_group)
        cls.other_course = Course.objects.create(
            title="Комп'ютерні мережі",
            credits=4,
            semester=2,
            academic_year="2025-2026",
            teacher=cls.other_teacher,
        )
        cls.other_course.groups.add(cls.other_group)

        cls.enrollment = Enrollment.objects.create(
            course=cls.course,
            student=cls.student,
            study_group=cls.study_group,
        )
        cls.peer_enrollment = Enrollment.objects.create(
            course=cls.course,
            student=cls.peer_student,
            study_group=cls.study_group,
        )
        cls.other_enrollment = Enrollment.objects.create(
            course=cls.other_course,
            student=cls.other_student,
            study_group=cls.other_group,
        )
        cls.assignment = Assignment.objects.create(
            course=cls.course,
            type=Assignment.Type.LAB,
            number=1,
            title="Лабораторна робота №1",
            max_score="10.00",
            weight="10.00",
        )
        cls.other_assignment = Assignment.objects.create(
            course=cls.other_course,
            type=Assignment.Type.LAB,
            number=1,
            title="Мережеві протоколи",
            max_score="10.00",
            weight="10.00",
        )

    @classmethod
    def create_student(cls, *, username, number, first_name, last_name, group):
        user = User.objects.create_user(
            username=username,
            email=f"{username}@example.com",
            password="StrongPass123!",
            role=User.Role.STUDENT,
        )
        return StudentProfile.objects.create(
            user=user,
            first_name=first_name,
            last_name=last_name,
            student_number=number,
            enrollment_year=2025,
            current_group=group,
        )
