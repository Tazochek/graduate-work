from django.urls import reverse

from grading.models import Assignment, Grade, GradeHistory, save_grade

from .base import GradingTestCase


class TeacherJournalViewTests(GradingTestCase):
    def test_anonymous_user_is_redirected_from_journal(self):
        url = reverse("grading:journal", args=[self.course.pk])
        response = self.client.get(url)
        self.assertRedirects(
            response,
            f"{reverse('accounts:login')}?next={url}",
        )

    def test_teacher_sees_own_journal(self):
        self.client.force_login(self.teacher.user)
        response = self.client.get(reverse("grading:journal", args=[self.course.pk]))
        self.assertContains(response, self.course.title)
        self.assertContains(response, self.student.last_name)
        self.assertContains(response, self.assignment.title)

    def test_teacher_cannot_open_foreign_journal(self):
        self.client.force_login(self.teacher.user)
        response = self.client.get(
            reverse("grading:journal", args=[self.other_course.pk])
        )
        self.assertEqual(response.status_code, 404)

    def test_teacher_creates_assignment_only_for_own_course(self):
        self.client.force_login(self.teacher.user)
        response = self.client.post(
            reverse("grading:assignment_create", args=[self.course.pk]),
            {
                "type": Assignment.Type.TEST,
                "number": 1,
                "title": "Модульний контроль",
                "max_score": "20.00",
                "weight": "20.00",
            },
        )
        self.assertRedirects(
            response,
            reverse("grading:journal", args=[self.course.pk]),
        )
        self.assertTrue(
            Assignment.objects.filter(
                course=self.course,
                type=Assignment.Type.TEST,
                number=1,
            ).exists()
        )

        response = self.client.post(
            reverse("grading:assignment_create", args=[self.other_course.pk]),
            {
                "type": Assignment.Type.TEST,
                "number": 2,
                "title": "Чужа робота",
                "max_score": "20.00",
                "weight": "20.00",
            },
        )
        self.assertEqual(response.status_code, 404)
        self.assertFalse(Assignment.objects.filter(title="Чужа робота").exists())

    def test_grade_view_writes_history(self):
        self.client.force_login(self.teacher.user)
        url = reverse(
            "grading:grade_update",
            args=[self.course.pk, self.enrollment.pk, self.assignment.pk],
        )
        response = self.client.post(
            url,
            {"score": "8.00", "comment": "Добра робота"},
        )
        self.assertRedirects(
            response,
            reverse("grading:journal", args=[self.course.pk]),
        )
        grade = Grade.objects.get(
            enrollment=self.enrollment,
            assignment=self.assignment,
        )
        history = GradeHistory.objects.get(grade=grade)
        self.assertEqual(history.action, GradeHistory.Action.CREATE)
        self.assertEqual(history.changed_by, self.teacher.user)

    def test_student_cannot_open_teacher_journal(self):
        self.client.force_login(self.student.user)
        response = self.client.get(reverse("grading:journal", args=[self.course.pk]))
        self.assertEqual(response.status_code, 403)


class StudentGradeViewTests(GradingTestCase):
    def test_student_sees_only_own_courses_and_scores(self):
        save_grade(
            Grade(
                enrollment=self.enrollment,
                assignment=self.assignment,
                score="8.00",
            ),
            self.teacher.user,
        )
        save_grade(
            Grade(
                enrollment=self.other_enrollment,
                assignment=self.other_assignment,
                score="10.00",
            ),
            self.other_teacher.user,
        )
        self.client.force_login(self.student.user)
        response = self.client.get(reverse("grading:student_dashboard"))

        self.assertContains(response, self.course.title)
        self.assertContains(response, "8,00")
        self.assertContains(
            response,
            "<strong>Підсумковий прогноз:</strong> 80",
            html=True,
        )
        self.assertContains(
            response,
            "<strong>Середнє групи:</strong> 40",
            html=True,
        )
        self.assertNotContains(response, self.other_course.title)
        self.assertNotContains(response, self.other_student.last_name)

    def test_teacher_cannot_open_student_dashboard(self):
        self.client.force_login(self.teacher.user)
        response = self.client.get(reverse("grading:student_dashboard"))
        self.assertEqual(response.status_code, 403)
