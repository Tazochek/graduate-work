from django.test import SimpleTestCase

from grading.scale import ects_grade


class EctsScaleTests(SimpleTestCase):
    def test_all_scale_boundaries(self):
        expected = {
            0: "F",
            34: "F",
            35: "FX",
            59: "FX",
            60: "E",
            63: "E",
            64: "D",
            73: "D",
            74: "C",
            81: "C",
            82: "B",
            89: "B",
            90: "A",
            100: "A",
        }
        for points, letter in expected.items():
            with self.subTest(points=points):
                self.assertEqual(ects_grade(points)[0], letter)

    def test_national_grade_matches_ects_band(self):
        self.assertEqual(ects_grade(95), ("A", "відмінно (5)"))
        self.assertEqual(ects_grade(80), ("C", "добре (4)"))
        self.assertEqual(ects_grade(62), ("E", "задовільно (3)"))
        self.assertIn("перескладання", ects_grade(50)[1])
        self.assertIn("повторне вивчення", ects_grade(20)[1])
