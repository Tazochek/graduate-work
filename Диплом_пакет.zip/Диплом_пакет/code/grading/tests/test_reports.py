from io import BytesIO

from django.urls import reverse
from openpyxl import load_workbook

from grading.models import Grade, save_grade
from grading.reports import build_course_workbook

from .base import GradingTestCase


class CourseReportTests(GradingTestCase):
    def setUp(self):
        save_grade(
            Grade(
                enrollment=self.enrollment,
                assignment=self.assignment,
                score="8.00",
            ),
            self.teacher.user,
        )

    def test_workbook_contains_course_student_and_result(self):
        content = build_course_workbook(self.course)
        workbook = load_workbook(BytesIO(content))
        worksheet = workbook.active

        self.assertEqual(worksheet["A1"].value, "Харківський національний університет радіоелектроніки")
        values = [cell.value for row in worksheet.iter_rows() for cell in row]
        self.assertIn(self.course.title, worksheet["A3"].value)
        self.assertTrue(
            any(self.student.last_name in str(value) for value in values)
        )
        self.assertIn(80, values)
        self.assertIn("C", values)

    def test_teacher_downloads_own_course_report(self):
        self.client.force_login(self.teacher.user)
        response = self.client.get(
            reverse("grading:course_report", args=[self.course.pk])
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("statement.xlsx", response["Content-Disposition"])
        self.assertGreater(len(response.content), 1000)

    def test_teacher_cannot_download_foreign_course_report(self):
        self.client.force_login(self.teacher.user)
        response = self.client.get(
            reverse("grading:course_report", args=[self.other_course.pk])
        )
        self.assertEqual(response.status_code, 404)

    def test_admin_downloads_any_course_report(self):
        self.client.force_login(self.admin_user)
        response = self.client.get(
            reverse("grading:course_report", args=[self.other_course.pk])
        )
        self.assertEqual(response.status_code, 200)
