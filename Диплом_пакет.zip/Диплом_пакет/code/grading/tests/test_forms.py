from grading.forms import AssignmentForm, GradeForm
from grading.models import Assignment, Grade

from .base import GradingTestCase


class GradingFormTests(GradingTestCase):
    def test_assignment_form_rejects_duplicate_type_and_number(self):
        form = AssignmentForm(
            data={
                "type": Assignment.Type.LAB,
                "number": 1,
                "title": "Дублікат",
                "max_score": "10.00",
                "weight": "10.00",
            },
            course=self.course,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("number", form.errors)

    def test_grade_form_uses_model_cross_table_validation(self):
        grade = Grade(
            enrollment=self.enrollment,
            assignment=self.assignment,
        )
        form = GradeForm(
            data={"score": "11.00", "comment": "Завеликий бал"},
            instance=grade,
        )
        self.assertFalse(form.is_valid())
        self.assertIn("score", form.errors)
