from decimal import Decimal
from types import SimpleNamespace

from django.test import SimpleTestCase

from grading.calculations import calculate_score


def assignment(pk, max_score, weight):
    return SimpleNamespace(pk=pk, max_score=Decimal(max_score), weight=Decimal(weight))


def grade(assignment_id, score):
    return SimpleNamespace(assignment_id=assignment_id, score=Decimal(score))


class ScoreCalculationTests(SimpleTestCase):
    def test_decision_example_returns_current_90_and_final_18(self):
        assignments = [
            assignment(1, "10", "10"),
            assignment(2, "10", "10"),
            assignment(3, "20", "20"),
            assignment(4, "100", "60"),
        ]
        grades = [grade(1, "8"), grade(2, "10")]

        self.assertEqual(calculate_score(assignments, grades, "current"), 90)
        self.assertEqual(calculate_score(assignments, grades, "final"), 18)

    def test_fully_graded_course_has_same_current_and_final_score(self):
        assignments = [
            assignment(1, "10", "50"),
            assignment(2, "20", "50"),
        ]
        grades = [grade(1, "5"), grade(2, "20")]

        self.assertEqual(calculate_score(assignments, grades, "current"), 75)
        self.assertEqual(calculate_score(assignments, grades, "final"), 75)

    def test_course_without_grades_returns_zero(self):
        assignments = [assignment(1, "10", "100")]
        self.assertEqual(calculate_score(assignments, [], "current"), 0)
        self.assertEqual(calculate_score(assignments, [], "final"), 0)

    def test_result_uses_mathematical_rounding(self):
        assignments = [assignment(1, "3", "100")]
        grades = [grade(1, "2")]
        self.assertEqual(calculate_score(assignments, grades, "final"), 67)
