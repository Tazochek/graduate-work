from decimal import Decimal, ROUND_HALF_UP


def calculate_score(assignments, grades, mode="current"):
    """Рахує поточний або підсумковий бал з однакових внесків робіт."""
    if mode not in {"current", "final"}:
        raise ValueError("Режим має дорівнювати 'current' або 'final'.")

    assignments = list(assignments)
    grades_by_assignment = {
        grade.assignment_id: Decimal(str(grade.score)) for grade in grades
    }
    contribution = Decimal("0")
    denominator = Decimal("0")

    for assignment in assignments:
        weight = Decimal(str(assignment.weight))
        score = grades_by_assignment.get(assignment.pk)
        if mode == "final" or score is not None:
            denominator += weight
        if score is not None:
            max_score = Decimal(str(assignment.max_score))
            contribution += score / max_score * weight

    if denominator == 0:
        return Decimal("0")
    result = contribution / denominator * Decimal("100")
    return result.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
