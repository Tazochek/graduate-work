from django.urls import path

from . import views


app_name = "grading"

urlpatterns = [
    path("student/", views.student_dashboard, name="student_dashboard"),
    path("courses/<int:course_pk>/", views.journal, name="journal"),
    path(
        "courses/<int:course_pk>/assignments/create/",
        views.assignment_create,
        name="assignment_create",
    ),
    path(
        "courses/<int:course_pk>/assignments/<int:pk>/edit/",
        views.assignment_update,
        name="assignment_update",
    ),
    path(
        "courses/<int:course_pk>/grades/<int:enrollment_pk>/<int:assignment_pk>/",
        views.grade_update,
        name="grade_update",
    ),
    path(
        "courses/<int:course_pk>/grades/<int:enrollment_pk>/<int:assignment_pk>/delete/",
        views.grade_delete,
        name="grade_delete",
    ),
    path(
        "courses/<int:course_pk>/statement.xlsx",
        views.course_report,
        name="course_report",
    ),
]
