from django import forms

from .models import Assignment, Grade


class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ("type", "number", "title", "max_score", "weight", "date")
        widgets = {"date": forms.DateInput(attrs={"type": "date"})}

    def __init__(self, *args, course, **kwargs):
        super().__init__(*args, **kwargs)
        self.course = course
        self.instance.course = course

    def clean(self):
        cleaned_data = super().clean()
        assignment_type = cleaned_data.get("type")
        number = cleaned_data.get("number")
        if assignment_type and number:
            duplicate = Assignment.objects.filter(
                course=self.course,
                type=assignment_type,
                number=number,
            ).exclude(pk=self.instance.pk)
            if duplicate.exists():
                self.add_error(
                    "number",
                    "Робота цього типу з таким номером уже існує.",
                )
        return cleaned_data


class GradeForm(forms.ModelForm):
    class Meta:
        model = Grade
        fields = ("score", "comment")
