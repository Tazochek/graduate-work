from django.contrib import admin

from .models import (
    Assignment,
    Grade,
    GradeHistory,
    delete_grade,
    save_grade,
)


@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "course",
        "type",
        "number",
        "max_score",
        "weight",
        "date",
    )
    list_filter = ("type", "course")
    search_fields = ("title", "course__title")
    list_select_related = ("course",)

    def get_readonly_fields(self, request, obj=None):
        return ("course",) if obj else ()


@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ("enrollment", "assignment", "score", "updated_at")
    list_filter = ("assignment__course",)
    search_fields = (
        "enrollment__student__last_name",
        "enrollment__student__student_number",
        "assignment__title",
    )
    list_select_related = (
        "enrollment__student",
        "assignment__course",
    )

    def get_readonly_fields(self, request, obj=None):
        return ("enrollment", "assignment") if obj else ()

    def save_model(self, request, obj, form, change):
        save_grade(obj, request.user)

    def delete_model(self, request, obj):
        delete_grade(obj, request.user)

    def get_actions(self, request):
        actions = super().get_actions(request)
        actions.pop("delete_selected", None)
        return actions


@admin.register(GradeHistory)
class GradeHistoryAdmin(admin.ModelAdmin):
    list_display = (
        "assignment",
        "enrollment",
        "action",
        "old_score",
        "new_score",
        "changed_by",
        "changed_at",
    )
    list_filter = ("action", "assignment__course")
    search_fields = (
        "enrollment__student__last_name",
        "assignment__title",
        "changed_by__username",
    )
    list_select_related = (
        "assignment",
        "enrollment__student",
        "changed_by",
    )
    readonly_fields = (
        "grade",
        "enrollment",
        "assignment",
        "action",
        "old_score",
        "new_score",
        "old_comment",
        "new_comment",
        "changed_by",
        "changed_at",
    )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
