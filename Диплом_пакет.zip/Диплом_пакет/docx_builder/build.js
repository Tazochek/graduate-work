const fs = require("fs");
const path = require("path");
const {
  AlignmentType,
  BorderStyle,
  Document,
  Header,
  HeadingLevel,
  ImageRun,
  LevelFormat,
  LevelSuffix,
  LineRuleType,
  Packer,
  PageNumber,
  PageOrientation,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableLayoutType,
  TableOfContents,
  TableRow,
  TextRun,
  VerticalAlign,
  WidthType,
} = require("docx");

// Профіль довгої академічної записки. За основу взято narrative_proposal,
// але всі параметри сторінки й тексту замінено точними вимогами завдання.
const PROFILE = Object.freeze({
  preset: "narrative_proposal_with_dstu_overrides",
  coverPattern: "editorial_cover_with_dstu_overrides",
  page: {
    width: 11906,
    height: 16838,
    marginTop: 1134,
    marginRight: 567,
    marginBottom: 1134,
    marginLeft: 1701,
    header: 567,
    footer: 567,
    contentWidth: 9638,
  },
  body: {
    font: "Times New Roman",
    size: 28,
    line: 360,
    firstLine: 709,
    color: "000000",
  },
  code: {
    font: "Courier New",
    size: 21,
    line: 240,
  },
  table: {
    font: "Times New Roman",
    size: 24,
    line: 260,
    indent: 120,
    width: 9518,
    cellTop: 80,
    cellBottom: 80,
    cellLeft: 100,
    cellRight: 100,
  },
});

const ROOT = path.resolve(__dirname, "..");
const INPUT = path.join(ROOT, "DIPLOMA_DRAFT.md");
const OUTPUT = path.join(ROOT, "Диплом.docx");
const IMAGE_DIRS = [
  path.join(__dirname, "assets"),
  path.join(ROOT, "assets"),
  path.join(ROOT, "diagrams"),
  path.join(ROOT, "screenshots"),
];

const source = fs.readFileSync(INPUT, "utf8").replace(/^\uFEFF/, "");
const lines = source.split(/\r?\n/);

function lineMatches(regex) {
  const matches = [];
  lines.forEach((line, index) => {
    if (regex.test(line)) {
      matches.push({ line: index + 1, text: line });
    }
    regex.lastIndex = 0;
  });
  return matches;
}

function countChars(text, char) {
  return [...text].filter((item) => item === char).length;
}

function stripCodeBlocks(text) {
  let inside = false;
  return text
    .split(/\r?\n/)
    .map((line) => {
      if (/^```/.test(line.trim())) {
        inside = !inside;
        return "";
      }
      return inside ? "" : line;
    })
    .join("\n");
}

function runPreflight() {
  const forbidden = [
    { name: "U+2014", escaped: "\\u2014", char: "\u2014" },
    { name: "U+2013", escaped: "\\u2013", char: "\u2013" },
  ];
  let forbiddenCount = 0;

  console.log("=== Перевірка DIPLOMA_DRAFT.md ===");
  forbidden.forEach((item) => {
    const hits = lines
      .map((line, index) => ({ line: index + 1, text: line }))
      .filter((entry) => entry.text.includes(item.char));
    forbiddenCount += hits.length;
    console.log(`${item.name}: ${hits.length}`);
    hits.forEach((hit) => console.error(`  рядок ${hit.line}: ${hit.text}`));
  });

  const patterns = [
    ["у сучасному світі", /у сучасному світі/iu],
    ["відіграє ключову або важливу роль", /відіграє\s+(?:ключову|важливу)\s+роль/iu],
    ["варто зазначити", /варто зазначити/iu],
    ["слід зауважити", /слід зауважити/iu],
    ["не лише ... а й", /не лише.{0,120}а й/iu],
    ["це не просто ... це", /це не просто.{0,120}[,.!?;:]?\s*це/iu],
    ["майбутнє виглядає", /майбутнє виглядає/iu],
    [
      "рекламна трійка",
      /(?:швидко|зручно|надійно|ефективно|якісно)\s*,\s*(?:швидко|зручно|надійно|ефективно|якісно)\s+(?:та|і)\s+(?:швидко|зручно|надійно|ефективно|якісно)/iu,
    ],
  ];
  let aiCount = 0;
  patterns.forEach(([name, regex]) => {
    const hits = lineMatches(regex);
    aiCount += hits.length;
    console.log(`Шаблон "${name}": ${hits.length}`);
    hits.forEach((hit) => console.warn(`  рядок ${hit.line}: ${hit.text}`));
  });

  const placeholders = lineMatches(/\[УТОЧНИТИ(?:[^\]]*)\]/giu);
  console.log(`[УТОЧНИТИ]: ${placeholders.length}`);
  placeholders.forEach((hit) => console.warn(`  рядок ${hit.line}: ${hit.text}`));

  const prose = stripCodeBlocks(source);
  const quotes = {
    leftUkrainian: countChars(prose, "«"),
    rightUkrainian: countChars(prose, "»"),
    straight: countChars(prose, '"'),
  };
  console.log(
    `Лапки у звичайному тексті: «=${quotes.leftUkrainian}, »=${quotes.rightUkrainian}, прямі=${quotes.straight}`,
  );
  if (quotes.leftUkrainian !== quotes.rightUkrainian) {
    console.warn("  Увага: кількість відкривальних і закривальних українських лапок різна.");
  }
  if (quotes.straight > 0 && quotes.leftUkrainian > 0) {
    console.warn("  Увага: у звичайному тексті змішані прямі й українські лапки.");
  }

  const wordCount = source.trim() === "" ? 0 : source.trim().split(/\s+/u).length;
  const approximatePages = Math.ceil(wordCount / 220);
  console.log(`Слів: ${wordCount}`);
  console.log(`Орієнтовно сторінок до візуального рендеру: ${approximatePages}`);
  console.log(`Мовних шаблонів: ${aiCount}`);

  if (forbiddenCount > 0) {
    throw new Error(
      "Збірку зупинено: виправте символи U+2013/U+2014 у DIPLOMA_DRAFT.md.",
    );
  }

  return { wordCount, approximatePages, placeholders: placeholders.length, aiCount };
}

function parseMarkdown(markdownLines) {
  const blocks = [];
  let paragraph = [];
  let index = 0;

  function flushParagraph() {
    if (paragraph.length > 0) {
      blocks.push({ type: "paragraph", text: paragraph.join(" ").trim() });
      paragraph = [];
    }
  }

  while (index < markdownLines.length) {
    const line = markdownLines[index];
    const trimmed = line.trim();

    if (trimmed === "") {
      flushParagraph();
      index += 1;
      continue;
    }

    if (trimmed.startsWith("```")) {
      flushParagraph();
      const language = trimmed.slice(3).trim();
      const code = [];
      index += 1;
      while (index < markdownLines.length && !markdownLines[index].trim().startsWith("```")) {
        code.push(markdownLines[index]);
        index += 1;
      }
      if (index < markdownLines.length) index += 1;
      blocks.push({ type: "code", language, lines: code });
      continue;
    }

    const heading = /^(#{1,3})\s+(.+)$/.exec(trimmed);
    if (heading) {
      flushParagraph();
      blocks.push({ type: "heading", level: heading[1].length, text: heading[2].trim() });
      index += 1;
      continue;
    }

    if (/^\|.*\|$/.test(trimmed) && index + 1 < markdownLines.length) {
      const separator = markdownLines[index + 1].trim();
      if (/^\|(?:\s*:?-+:?\s*\|)+$/.test(separator)) {
        flushParagraph();
        const rows = [];
        rows.push(splitTableRow(trimmed));
        index += 2;
        while (index < markdownLines.length && /^\|.*\|$/.test(markdownLines[index].trim())) {
          rows.push(splitTableRow(markdownLines[index].trim()));
          index += 1;
        }
        blocks.push({ type: "table", rows });
        continue;
      }
    }

    const numbered = /^\d+\.\s+(.+)$/.exec(trimmed);
    if (numbered) {
      flushParagraph();
      const items = [];
      while (index < markdownLines.length) {
        const match = /^\d+\.\s+(.+)$/.exec(markdownLines[index].trim());
        if (!match) break;
        items.push(match[1]);
        index += 1;
      }
      blocks.push({ type: "list", ordered: true, items });
      continue;
    }

    const bullet = /^[-*]\s+(.+)$/.exec(trimmed);
    if (bullet) {
      flushParagraph();
      const items = [];
      while (index < markdownLines.length) {
        const match = /^[-*]\s+(.+)$/.exec(markdownLines[index].trim());
        if (!match) break;
        items.push(match[1]);
        index += 1;
      }
      blocks.push({ type: "list", ordered: false, items });
      continue;
    }

    if (/^\[(?:Рисунок|Вставити|За потреби вставити)(?:\s|`).*\]$/iu.test(trimmed)) {
      flushParagraph();
      blocks.push({ type: "figure", text: trimmed });
      index += 1;
      continue;
    }

    paragraph.push(trimmed);
    index += 1;
  }

  flushParagraph();
  return blocks;
}

function splitTableRow(line) {
  return line
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((cell) => cell.trim());
}

function inlineRuns(text, options = {}) {
  const font = options.font || PROFILE.body.font;
  const size = options.size || PROFILE.body.size;
  const bold = options.bold || false;
  const color = options.color || PROFILE.body.color;
  const runs = [];
  const regex = /`([^`]+)`|\*\*([^*]+)\*\*/g;
  let cursor = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > cursor) {
      runs.push(new TextRun({ text: text.slice(cursor, match.index), font, size, bold, color }));
    }
    if (match[1] !== undefined) {
      runs.push(
        new TextRun({
          text: match[1],
          font: PROFILE.code.font,
          size: Math.min(size, 22),
          color,
        }),
      );
    } else {
      runs.push(new TextRun({ text: match[2], font, size, bold: true, color }));
    }
    cursor = regex.lastIndex;
  }

  if (cursor < text.length) {
    runs.push(new TextRun({ text: text.slice(cursor), font, size, bold, color }));
  }
  if (runs.length === 0) runs.push(new TextRun({ text: "", font, size, color }));
  return runs;
}

function bodyParagraph(text) {
  return new Paragraph({
    style: "DiplomaBody",
    children: inlineRuns(text),
  });
}

function structuralHeading(text) {
  const appendix = /^(Додаток\s+[А-ЯA-Z])\.\s*(.+)$/iu.exec(text);
  if (appendix) {
    return new Paragraph({
      heading: HeadingLevel.HEADING_1,
      children: [
        new TextRun({
          text: appendix[1].toLocaleUpperCase("uk-UA"),
          font: PROFILE.body.font,
          size: PROFILE.body.size,
          bold: true,
        }),
        new TextRun({
          text: appendix[2].toLocaleUpperCase("uk-UA"),
          break: 1,
          font: PROFILE.body.font,
          size: PROFILE.body.size,
          bold: true,
        }),
      ],
    });
  }
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [
      new TextRun({
        text: text.toLocaleUpperCase("uk-UA"),
        font: PROFILE.body.font,
        size: PROFILE.body.size,
        bold: true,
      }),
    ],
  });
}

function subsectionHeading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [
      new TextRun({
        text,
        font: PROFILE.body.font,
        size: PROFILE.body.size,
        bold: true,
      }),
    ],
  });
}

function buildCover(titleBlocks) {
  const title = titleBlocks.find((block) => block.type === "heading" && block.level === 1)?.text || "";
  const metadata = titleBlocks
    .filter((block) => block.type === "paragraph")
    .map((block) => block.text);
  const theme = metadata.find((line) => line.startsWith("Тема:")) || "";
  const city = metadata.find((line) => /^Харків\s+\d{4}$/u.test(line)) || "";
  const details = metadata.filter((line) => line !== theme && line !== city);
  const children = [];

  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 900, after: 180, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
      children: [
        new TextRun({
          text: title,
          font: PROFILE.body.font,
          size: PROFILE.body.size,
          bold: true,
          color: PROFILE.body.color,
        }),
      ],
    }),
  );
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 620, after: 620, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
      children: inlineRuns(theme, { bold: true }),
    }),
  );
  details.forEach((line, index) => {
    children.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        indent: { left: index === 0 || index === details.length - 1 ? 2600 : 0 },
        spacing: {
          before: index === 0 ? 220 : 0,
          after: 120,
          line: PROFILE.body.line,
          lineRule: LineRuleType.AUTO,
        },
        children: inlineRuns(line),
      }),
    );
  });
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 760, after: 0, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
      children: inlineRuns(city),
    }),
  );
  return children;
}

function chooseColumnWidths(rows) {
  const columns = rows[0].length;
  const header = rows[0].map((cell) => cell.toLocaleLowerCase("uk-UA"));
  const width = PROFILE.table.width;
  let ratios;

  if (columns === 4 && header[0] === "код") ratios = [0.09, 0.22, 0.18, 0.51];
  else if (columns === 4 && header[1] === "ects") ratios = [0.18, 0.12, 0.52, 0.18];
  else if (columns === 3 && header[0] === "підхід") ratios = [0.2, 0.28, 0.52];
  else if (columns === 3 && header[1] === "кількість") ratios = [0.42, 0.12, 0.46];
  else {
    const weights = Array.from({ length: columns }, (_, column) => {
      const longest = Math.max(...rows.map((row) => (row[column] || "").length));
      return Math.max(8, Math.sqrt(longest + 1));
    });
    const sum = weights.reduce((acc, item) => acc + item, 0);
    ratios = weights.map((item) => item / sum);
  }

  const result = ratios.map((ratio) => Math.floor(width * ratio));
  result[result.length - 1] += width - result.reduce((acc, item) => acc + item, 0);
  return result;
}

function cleanInlineMarkup(text) {
  return text.replace(/`([^`]+)`/g, "$1").replace(/\*\*([^*]+)\*\*/g, "$1");
}

function tableCaption(chapter, counter, subsection) {
  const title = subsection.replace(/^\S+\s+/, "").trim() || "Дані";
  return new Paragraph({
    style: "TableCaption",
    children: inlineRuns(`Таблиця ${chapter}.${counter} - ${title}`),
  });
}

function buildTable(rows) {
  const columnWidths = chooseColumnWidths(rows);
  const border = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
  const tableRows = rows.map(
    (row, rowIndex) =>
      new TableRow({
        tableHeader: rowIndex === 0,
        cantSplit: false,
        children: row.map((cell, columnIndex) => {
          const cleaned = cleanInlineMarkup(cell);
          const isShort = cleaned.length <= 16 || /^\d+(?:[.,]\d+)?(?:-\d+)?$/u.test(cleaned);
          return new TableCell({
            width: { size: columnWidths[columnIndex], type: WidthType.DXA },
            verticalAlign: VerticalAlign.CENTER,
            shading:
              rowIndex === 0
                ? { type: ShadingType.CLEAR, fill: "E7E7E7", color: "auto" }
                : undefined,
            margins: {
              top: PROFILE.table.cellTop,
              bottom: PROFILE.table.cellBottom,
              left: PROFILE.table.cellLeft,
              right: PROFILE.table.cellRight,
            },
            children: [
              new Paragraph({
                alignment: rowIndex === 0 || isShort ? AlignmentType.CENTER : AlignmentType.LEFT,
                spacing: { before: 0, after: 0, line: PROFILE.table.line, lineRule: LineRuleType.AUTO },
                children: inlineRuns(cell, {
                  font: PROFILE.table.font,
                  size: PROFILE.table.size,
                  bold: rowIndex === 0,
                }),
              }),
            ],
          });
        }),
      }),
  );

  return new Table({
    rows: tableRows,
    width: { size: PROFILE.table.width, type: WidthType.DXA },
    indent: { size: PROFILE.table.indent, type: WidthType.DXA },
    columnWidths,
    layout: TableLayoutType.FIXED,
    alignment: AlignmentType.LEFT,
    margins: {
      top: PROFILE.table.cellTop,
      bottom: PROFILE.table.cellBottom,
      left: PROFILE.table.cellLeft,
      right: PROFILE.table.cellRight,
    },
    borders: {
      top: border,
      bottom: border,
      left: border,
      right: border,
      insideHorizontal: border,
      insideVertical: border,
    },
  });
}

function findImage(filename) {
  for (const directory of IMAGE_DIRS) {
    const candidate = path.join(directory, filename);
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function pngDimensions(buffer) {
  const signature = buffer.subarray(0, 8).toString("hex");
  if (signature !== "89504e470d0a1a0a") throw new Error("Підтримуються PNG-зображення.");
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

function scaleImage(buffer) {
  const original = pngDimensions(buffer);
  const maxWidth = 610;
  const maxHeight = 720;
  const ratio = Math.min(maxWidth / original.width, maxHeight / original.height, 1);
  return {
    width: Math.max(1, Math.round(original.width * ratio)),
    height: Math.max(1, Math.round(original.height * ratio)),
  };
}

function figureDescriptor(text, currentSubsection) {
  const bodyFigure = /^\[Рисунок\s+([0-9А-ЯA-Z]+(?:\.[0-9]+)?)\.\s*(.+)\]$/iu.exec(text);
  if (bodyFigure) {
    const title = bodyFigure[2].trim();
    const lower = title.toLocaleLowerCase("uk-UA");
    let filename = null;
    if (lower.includes("er-діаграма")) filename = "diagram_er.png";
    else if (lower.includes("класів")) filename = "diagram_classes.png";
    else if (lower.includes("варіантів використання")) filename = "diagram_usecase.png";
    else if (lower.includes("послідовності")) filename = "diagram_sequence.png";
    else if (lower.includes("розгортання")) filename = "diagram_deploy.png";
    return { number: bodyFigure[1], title, filename };
  }

  const fileMatch = /`([^`]+\.(?:png|jpg|jpeg))`/iu.exec(text);
  const subsection = /^(\S+)\s+(.+)$/u.exec(currentSubsection || "");
  return {
    number: subsection ? subsection[1] : "[УТОЧНИТИ]",
    title: subsection ? subsection[2] : text.replace(/^\[|\]$/g, ""),
    filename: fileMatch ? fileMatch[1] : null,
    optional: /^\[За потреби вставити(?:\s|`)/iu.test(text),
  };
}

function buildFigure(text, currentSubsection, imageReport) {
  const descriptor = figureDescriptor(text, currentSubsection);
  const imagePath = descriptor.filename ? findImage(descriptor.filename) : null;
  if (!imagePath) {
    const missingName = descriptor.filename || descriptor.title;
    if (descriptor.optional) {
      imageReport.skippedOptional.push(missingName);
      return [];
    }
    imageReport.missing.push(missingName);
    return [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 120, line: 280, lineRule: LineRuleType.AUTO },
        keepLines: true,
        children: [
          new TextRun({
            text: `[РИСУНОК НЕ ВСТАВЛЕНО: ${missingName}]`,
            font: PROFILE.body.font,
            size: 26,
            bold: true,
            color: "B00020",
          }),
        ],
      }),
    ];
  }

  const data = fs.readFileSync(imagePath);
  const dimensions = scaleImage(data);
  imageReport.inserted.push(path.basename(imagePath));
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 120, after: 60 },
      keepNext: true,
      children: [
        new ImageRun({
          type: "png",
          data,
          transformation: dimensions,
          altText: {
            title: descriptor.title,
            description: descriptor.title,
            name: descriptor.filename,
          },
        }),
      ],
    }),
    new Paragraph({
      style: "FigureCaption",
      children: inlineRuns(`Рисунок ${descriptor.number} - ${descriptor.title}`),
    }),
  ];
}

function buildNamedFigure(filename, number, title, imageReport) {
  const imagePath = findImage(filename);
  if (!imagePath) {
    imageReport.missing.push(filename);
    return [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 120, after: 120, line: 280, lineRule: LineRuleType.AUTO },
        children: [
          new TextRun({
            text: `[РИСУНОК НЕ ВСТАВЛЕНО: ${filename}]`,
            font: PROFILE.body.font,
            size: 26,
            bold: true,
            color: "B00020",
          }),
        ],
      }),
    ];
  }

  const data = fs.readFileSync(imagePath);
  const dimensions = scaleImage(data);
  imageReport.inserted.push(path.basename(imagePath));
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 120, after: 60 },
      keepNext: true,
      children: [
        new ImageRun({
          type: "png",
          data,
          transformation: dimensions,
          altText: { title, description: title, name: filename },
        }),
      ],
    }),
    new Paragraph({
      style: "FigureCaption",
      children: inlineRuns(`Рисунок ${number} - ${title}`),
    }),
  ];
}

function buildCode(linesOfCode) {
  return linesOfCode.map(
    (line, index) =>
      new Paragraph({
        style: "CodeBlock",
        keepNext: index === 0 && linesOfCode.length > 1,
        children: [
          new TextRun({
            text: line || " ",
            font: PROFILE.code.font,
            size: PROFILE.code.size,
            color: "000000",
            noProof: true,
          }),
        ],
      }),
  );
}

function buildNumbering(blocks) {
  let index = 0;
  const references = [];
  blocks.forEach((block) => {
    if (block.type !== "list") return;
    index += 1;
    block.reference = `diploma-list-${index}`;
    references.push({
      reference: block.reference,
      levels: [
        {
          level: 0,
          format: block.ordered ? LevelFormat.DECIMAL : LevelFormat.BULLET,
          text: block.ordered ? "%1." : "•",
          alignment: AlignmentType.LEFT,
          start: 1,
          suffix: LevelSuffix.TAB,
          style: {
            run: { font: PROFILE.body.font, size: PROFILE.body.size },
            paragraph: {
              indent: { left: 709, hanging: 360 },
              spacing: { before: 0, after: 0, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
            },
          },
        },
      ],
    });
  });
  return references;
}

function createStyles() {
  return {
    default: {
      document: {
        run: {
          font: PROFILE.body.font,
          size: PROFILE.body.size,
          color: PROFILE.body.color,
        },
        paragraph: {
          alignment: AlignmentType.JUSTIFIED,
          spacing: { before: 0, after: 0, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
        },
      },
    },
    paragraphStyles: [
      {
        id: "DiplomaBody",
        name: "Diploma Body",
        basedOn: "Normal",
        next: "DiplomaBody",
        quickFormat: true,
        run: { font: PROFILE.body.font, size: PROFILE.body.size, color: PROFILE.body.color },
        paragraph: {
          alignment: AlignmentType.JUSTIFIED,
          indent: { firstLine: PROFILE.body.firstLine },
          spacing: { before: 0, after: 0, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
          widowControl: true,
        },
      },
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "DiplomaBody",
        quickFormat: true,
        run: { font: PROFILE.body.font, size: PROFILE.body.size, bold: true, color: "000000" },
        paragraph: {
          alignment: AlignmentType.CENTER,
          spacing: { before: 0, after: 240, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
          pageBreakBefore: true,
          keepNext: true,
          keepLines: true,
          outlineLevel: 0,
        },
      },
      {
        id: "Heading2",
        name: "Heading 2",
        basedOn: "Normal",
        next: "DiplomaBody",
        quickFormat: true,
        run: { font: PROFILE.body.font, size: PROFILE.body.size, bold: true, color: "000000" },
        paragraph: {
          alignment: AlignmentType.LEFT,
          indent: { firstLine: PROFILE.body.firstLine },
          spacing: { before: 240, after: 120, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
          keepNext: true,
          keepLines: true,
          outlineLevel: 1,
        },
      },
      {
        id: "TocTitle",
        name: "TOC Title",
        basedOn: "Normal",
        next: "Normal",
        run: { font: PROFILE.body.font, size: PROFILE.body.size, bold: true, color: "000000" },
        paragraph: {
          alignment: AlignmentType.CENTER,
          spacing: { before: 0, after: 240, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
          pageBreakBefore: true,
          keepNext: true,
        },
      },
      {
        id: "TableCaption",
        name: "Table Caption",
        basedOn: "Normal",
        next: "Normal",
        run: { font: PROFILE.body.font, size: PROFILE.body.size, color: "000000" },
        paragraph: {
          alignment: AlignmentType.LEFT,
          indent: { firstLine: PROFILE.body.firstLine },
          spacing: { before: 120, after: 80, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
          keepNext: true,
        },
      },
      {
        id: "FigureCaption",
        name: "Figure Caption",
        basedOn: "Normal",
        next: "DiplomaBody",
        run: { font: PROFILE.body.font, size: PROFILE.body.size, color: "000000" },
        paragraph: {
          alignment: AlignmentType.CENTER,
          spacing: { before: 0, after: 180, line: PROFILE.body.line, lineRule: LineRuleType.AUTO },
          keepLines: true,
        },
      },
      {
        id: "CodeBlock",
        name: "Code Block",
        basedOn: "Normal",
        next: "CodeBlock",
        run: { font: PROFILE.code.font, size: PROFILE.code.size, color: "000000" },
        paragraph: {
          alignment: AlignmentType.LEFT,
          indent: { left: 0, right: 0, firstLine: 0 },
          spacing: { before: 0, after: 0, line: PROFILE.code.line, lineRule: LineRuleType.AUTO },
          widowControl: false,
        },
      },
    ],
  };
}

function buildDocument(blocks) {
  const firstMainHeading = blocks.findIndex(
    (block) => block.type === "heading" && block.level === 2,
  );
  if (firstMainHeading < 0) throw new Error("Не знайдено заголовок Реферат.");

  const titleBlocks = blocks.slice(0, firstMainHeading);
  const mainBlocks = blocks.slice(firstMainHeading);
  const children = buildCover(titleBlocks);
  const imageReport = { inserted: [], missing: [], skippedOptional: [] };
  const tableCounters = new Map();
  let currentChapter = "0";
  let currentSubsection = "";
  let sawAbstract = false;
  let tocInserted = false;
  let appendixBDiagramTitles = [];
  let appendixBDiagramsInserted = false;

  mainBlocks.forEach((block) => {
    if (block.type === "heading" && block.level === 2) {
      if (sawAbstract && !tocInserted && block.text.toLocaleLowerCase("uk-UA") === "вступ") {
        children.push(
          new Paragraph({
            style: "TocTitle",
            children: [
              new TextRun({
                text: "ЗМІСТ",
                font: PROFILE.body.font,
                size: PROFILE.body.size,
                bold: true,
              }),
            ],
          }),
        );
        children.push(
          new TableOfContents("Зміст", {
            hyperlink: true,
            headingStyleRange: "1-2",
            beginDirty: true,
          }),
        );
        tocInserted = true;
      }
      if (block.text.toLocaleLowerCase("uk-UA") === "abstract") sawAbstract = true;
      const chapterMatch = /^(\d+)\s+/u.exec(block.text);
      const appendixMatch = /^Додаток\s+([А-ЯA-Z])/iu.exec(block.text);
      currentChapter = chapterMatch ? chapterMatch[1] : appendixMatch ? appendixMatch[1] : "0";
      currentSubsection = "";
      children.push(structuralHeading(block.text));
      return;
    }

    if (block.type === "heading" && block.level === 3) {
      currentSubsection = block.text;
      children.push(subsectionHeading(block.text));
      return;
    }

    if (block.type === "paragraph") {
      children.push(bodyParagraph(block.text));
      if (
        currentChapter === "Б" &&
        !appendixBDiagramsInserted &&
        /diagram_er\.png/iu.test(block.text)
      ) {
        const filenames = [
          "diagram_er.png",
          "diagram_classes.png",
          "diagram_usecase.png",
          "diagram_sequence.png",
          "diagram_deploy.png",
        ];
        filenames.forEach((filename, index) => {
          const title = (appendixBDiagramTitles[index] || filename).replace(/[.]$/u, "");
          children.push(
            ...buildNamedFigure(filename, `Б.${index + 1}`, title, imageReport),
          );
        });
        appendixBDiagramsInserted = true;
      }
      return;
    }

    if (block.type === "list") {
      if (currentChapter === "Б" && block.ordered) {
        appendixBDiagramTitles = [...block.items];
      }
      block.items.forEach((item) => {
        children.push(
          new Paragraph({
            style: "DiplomaBody",
            numbering: { reference: block.reference, level: 0 },
            indent: { firstLine: 0 },
            children: inlineRuns(item),
          }),
        );
      });
      return;
    }

    if (block.type === "table") {
      const count = (tableCounters.get(currentChapter) || 0) + 1;
      tableCounters.set(currentChapter, count);
      children.push(tableCaption(currentChapter, count, currentSubsection));
      children.push(buildTable(block.rows));
      children.push(new Paragraph({ spacing: { after: 120 } }));
      return;
    }

    if (block.type === "figure") {
      children.push(...buildFigure(block.text, currentSubsection, imageReport));
      return;
    }

    if (block.type === "code") {
      children.push(...buildCode(block.lines));
    }
  });

  const pageNumber = new Paragraph({
    alignment: AlignmentType.RIGHT,
    spacing: { before: 0, after: 0 },
    children: [
      new TextRun({
        children: [PageNumber.CURRENT],
        font: PROFILE.body.font,
        size: PROFILE.body.size,
        color: "000000",
      }),
    ],
  });

  const document = new Document({
    title: "Пояснювальна записка до кваліфікаційної роботи бакалавра",
    subject: "Облік навчальних досягнень студентів",
    creator: "Студент ХНУРЕ",
    description: "Документ згенеровано з DIPLOMA_DRAFT.md без зміни змісту.",
    styles: createStyles(),
    numbering: { config: buildNumbering(blocks) },
    features: { updateFields: true },
    sections: [
      {
        properties: {
          titlePage: true,
          page: {
            size: {
              width: PROFILE.page.width,
              height: PROFILE.page.height,
              orientation: PageOrientation.PORTRAIT,
            },
            margin: {
              top: PROFILE.page.marginTop,
              right: PROFILE.page.marginRight,
              bottom: PROFILE.page.marginBottom,
              left: PROFILE.page.marginLeft,
              header: PROFILE.page.header,
              footer: PROFILE.page.footer,
            },
            pageNumbers: { start: 1 },
          },
        },
        headers: {
          first: new Header({ children: [new Paragraph({ children: [] })] }),
          default: new Header({ children: [pageNumber] }),
        },
        children,
      },
    ],
  });

  return { document, imageReport };
}

async function main() {
  const report = runPreflight();
  const blocks = parseMarkdown(lines);
  const numbering = buildNumbering(blocks);
  if (numbering.length === 0) console.warn("У Markdown не знайдено списків.");

  const { document, imageReport } = buildDocument(blocks);
  const buffer = await Packer.toBuffer(document);
  fs.writeFileSync(OUTPUT, buffer);

  console.log("=== Збірка DOCX ===");
  console.log(`Створено: ${OUTPUT}`);
  console.log(`Розмір: ${buffer.length} байт`);
  console.log(`Вставлено зображень: ${imageReport.inserted.length}`);
  imageReport.inserted.forEach((name) => console.log(`  + ${name}`));
  console.log(`Не вставлено зображень: ${imageReport.missing.length}`);
  imageReport.missing.forEach((name) => console.warn(`  - ${name}`));
  console.log(`Пропущено необов'язкових зображень: ${imageReport.skippedOptional.length}`);
  imageReport.skippedOptional.forEach((name) => console.log(`  ~ ${name}`));
  console.log(
    `Підсумок перевірки: тире 0, шаблонів ${report.aiCount}, [УТОЧНИТИ] ${report.placeholders}, орієнтовно ${report.approximatePages} сторінок.`,
  );
  console.log("Після відкриття у Word натисніть Ctrl+A, F9 і оновіть увесь зміст.");
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
